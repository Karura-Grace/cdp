#!/usr/bin/env bash
# CDP Platform - one-command local start (macOS / Linux). Needs Python 3.11+ and Node.js 20+.
set -e
cd "$(dirname "$0")"
[ -d backend/.venv ] || python3 -m venv backend/.venv
. backend/.venv/bin/activate
pip install -q -r backend/requirements.txt
[ -f frontend/dist/index.html ] || (cd frontend && npm install && npm run build)
cd backend
python -m app.seed --if-empty
echo "CDP Platform running at http://localhost:8000"
exec python -m uvicorn app.main:app --port 8000
