import { useEffect, useMemo, useRef, useState } from "react";
import { useParams } from "react-router-dom";
import { api, ApiError, OR } from "../api";
import { Err } from "../components/ui";

type Alloc = Record<string, number | "">;
const blank = (): Alloc => ({ ENGAGE: "", INNOVATE: "", PERFORM: "", GOVERN: "" });

export default function Survey() {
  const { token = "" } = useParams();
  const [sv, setSv] = useState<any>(null);
  const [err, setErr] = useState<ApiError | null>(null);
  const [step, setStep] = useState(-1);               // -1 consent, 0..35 scenario screens, 36 likert, 37 eos, 38 qual, 39 done
  const [alloc, setAlloc] = useState<Record<string, Alloc>>({});
  const [likert, setLikert] = useState<Record<string, (number | null)[]>>({});
  const [eos, setEos] = useState<(number | null)[]>(Array(8).fill(null));
  const [qual, setQual] = useState<Record<string, string>>({});
  const [status, setStatus] = useState("");
  const started = useRef(Date.now());
  useEffect(() => { api("/v1/survey", { params: { token } }).then(setSv).catch(setErr); }, [token]);

  const scen = sv?.instrument.scenarios || [];
  const screens = useMemo(() => scen.flatMap((s: any) => [{ s, p: "NOW" }, { s, p: "PREFERRED" }]), [scen]);
  const key = (p: string, id: string) => p + ":" + id;
  const cur = step >= 0 && step < screens.length ? screens[step] : null;
  const curA = cur ? alloc[key(cur.p, cur.s.scenario_id)] || blank() : blank();
  const total = OR.reduce((t, o) => t + (Number(curA[o]) || 0), 0);
  const L = screens.length;

  const payload = (submit: boolean) => {
    const out: any = { NOW: {}, PREFERRED: {} };
    for (const s of scen) for (const p of ["NOW", "PREFERRED"]) {
      const a = alloc[key(p, s.scenario_id)];
      const ok = a && OR.reduce((t, o) => t + (Number(a[o]) || 0), 0) === 100;
      (out[p][s.dimension] = out[p][s.dimension] || []).push(ok ? Object.fromEntries(OR.map(o => [o, Number(a[o]) || 0])) : null);
    }
    return { consent: true, alloc: out, likert, eos, qualitative: qual, submit, duration_seconds: Math.round((Date.now() - started.current) / 1000) };
  };
  const send = async (submit: boolean) => {
    try { const r = await api<any>("/v1/survey/response", { method: "PUT", params: { token }, body: payload(submit) }); setStatus(r.status); if (submit) setStep(L + 3); }
    catch (e: any) { setErr(e); }
  };
  const decline = async () => { await api("/v1/survey/response", { method: "PUT", params: { token }, body: { consent: false } }).catch(() => null); setStatus("DECLINED"); };

  const wrap = (body: any) => (
    <div style={{ maxWidth: 820, margin: "0 auto", padding: "24px 16px 80px" }}>
      <div style={{ background: "#1C2B4A", color: "#fff", borderRadius: 12, padding: "18px 22px", marginBottom: 16 }}>
        <div className="brand">CULTURE DYNAMICS PROFILE</div><div style={{ fontSize: 18, fontWeight: 700, marginTop: 4 }}>{sv?.organisation || "Survey"}</div>
        {step >= 0 && step <= L + 2 && <div style={{ height: 6, background: "rgba(255,255,255,.15)", borderRadius: 3, marginTop: 12 }}><div style={{ height: 6, width: `${(step / (L + 3)) * 100}%`, background: "#E8610A", borderRadius: 3 }} /></div>}
      </div>
      <Err e={err} />{body}
    </div>);

  if (err && !sv) return wrap(null);
  if (!sv) return wrap(<div className="card">Loading…</div>);
  if (status === "DECLINED") return wrap(<div className="card"><h3>Thank you</h3>You chose not to take part. No answers were recorded.</div>);
  if (step === L + 3) return wrap(<div className="card"><h3>Submitted</h3>Thank you. Your answers are now separated from your name and will only be reported in groups of at least five people.</div>);

  if (step === -1) return wrap(<div className="card">
    <h3>Before you begin</h3><p style={{ fontSize: 14.5, lineHeight: 1.55 }}>{sv.consent_text}</p>
    <p className="sub">About {sv.completion_estimate}. Open until {sv.window_close}. You can save and return using the same link.</p>
    <div style={{ display: "flex", gap: 8 }}><button className="btn orange" onClick={() => setStep(0)}>I agree – start</button><button className="btn alt" onClick={decline}>I do not wish to take part</button></div>
  </div>);

  const nav = (canNext: boolean, nextLabel = "Next") => <div style={{ display: "flex", justifyContent: "space-between", marginTop: 16 }}>
    <button className="btn alt" onClick={() => setStep(step - 1)}>Back</button>
    <div style={{ display: "flex", gap: 8 }}><button className="btn alt" onClick={() => send(false)}>Save and finish later</button>
      <button className="btn" disabled={!canNext} onClick={() => step === L + 2 ? send(true) : setStep(step + 1)}>{nextLabel}</button></div>
  </div>;

  if (cur) {
    const set = (o: string, v: string) => { const n = v === "" ? "" : Math.max(0, Math.min(100, parseInt(v) || 0));
      setAlloc({ ...alloc, [key(cur.p, cur.s.scenario_id)]: { ...curA, [o]: n } }); };
    return wrap(<div className="card">
      <div className="label">{cur.s.dimension} · scenario {Math.floor(step / 2) + 1} of {scen.length} · <span style={{ color: cur.p === "NOW" ? "#2E86C1" : "#E8610A" }}>{cur.p === "NOW" ? "HOW IT IS NOW" : "HOW IT SHOULD BE"}</span></div>
      <h3 style={{ fontSize: 18, margin: "6px 0" }}>{cur.s.title}</h3>
      <p style={{ fontSize: 14.5 }}>{cur.p === "NOW" ? cur.s.prompt_now : cur.s.prompt_preferred}</p>
      <p className="sub">Share 100 points across the four statements. Give more points to the statement that best describes {cur.p === "NOW" ? "the organisation today" : "how you would like it to be"}.</p>
      {cur.s.statements.map((st: any, i: number) => <div key={st.orientation} className="cs"><span style={{ fontSize: 14.5 }}><b>{String.fromCharCode(65 + i)}.</b> {st.text}</span>
        <input inputMode="numeric" aria-label={"Points for statement " + String.fromCharCode(65 + i)} value={curA[st.orientation]} onChange={e => set(st.orientation, e.target.value)} /></div>)}
      <div style={{ display: "flex", justifyContent: "flex-end", marginTop: 10 }}><span className={"total " + (total === 100 ? "good" : "bad")}>Total {total} / 100{total !== 100 ? ` · ${total < 100 ? 100 - total + " left" : total - 100 + " over"}` : " ✓"}</span></div>
      {nav(total === 100)}
    </div>);
  }

  if (step === L) {
    const dims = Object.entries(sv.instrument.likert) as [string, any[]][];
    const done = dims.every(([d, items]) => (likert[d] || []).filter(v => v != null).length === items.length);
    return wrap(<div className="card">
      <h3>Readiness and candour</h3><p className="sub">1 = strongly disagree · 5 = strongly agree</p>
      {dims.map(([d, items]) => <div key={d}><div className="label" style={{ marginTop: 16 }}>{d}</div>
        {items.map((it, i) => <div key={it.item_id} className="lk"><span>{it.text}</span>{[1, 2, 3, 4, 5].map(v =>
          <button key={v} className={(likert[d] || [])[i] === v ? "on" : ""} onClick={() => { const arr = [...(likert[d] || Array(items.length).fill(null))]; arr[i] = v; setLikert({ ...likert, [d]: arr }); }}>{v}</button>)}</div>)}</div>)}
      {nav(done)}
    </div>);
  }
  if (step === L + 1) return wrap(<div className="card">
    <h3>Your view of the organisation</h3><p className="sub">0 = not at all likely · 10 = extremely likely</p>
    {sv.instrument.eos.map((it: any, i: number) => <div key={it.item_id}><div style={{ fontSize: 14.5, marginTop: 10 }}>{it.text}</div>
      <div className="eosrow">{Array.from({ length: 11 }, (_, v) => <button key={v} className={eos[i] === v ? "on" : ""} onClick={() => { const a = [...eos]; a[i] = v; setEos(a); }}>{v}</button>)}</div></div>)}
    {nav(eos.every(v => v !== null))}
  </div>);
  return wrap(<div className="card">
    <h3>In your own words</h3><p className="sub">Optional. Please do not include names or details that could identify anyone.</p>
    {sv.instrument.qualitative.map((it: any) => <div key={it.item_id} style={{ marginTop: 12 }}><b>{it.title}</b><p style={{ fontSize: 14 }}>{it.text}</p>
      <textarea value={qual[it.item_id] || ""} onChange={e => setQual({ ...qual, [it.item_id]: e.target.value })} /></div>)}
    {nav(true, "Submit")}
  </div>);
}
