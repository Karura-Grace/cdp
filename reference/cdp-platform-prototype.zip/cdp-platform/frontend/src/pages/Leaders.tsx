import { A, OR } from "../api";
import { Card, Page, useApi, Err, Loading, Orient, Verdict } from "../components/ui";
import { Leader360Chart } from "../components/charts";

export default function Leaders() {
  const { data, error } = useApi<any[]>(`/v1/assessments/${A}/leaders`);
  if (error) return <Page title="Leader 360"><Err e={error} /></Page>;
  if (!data) return <Loading />;
  return (
    <Page title="Leader 360" sub="Visible only to the leader, their coach, the people lead and PAC. Rater groups below three are merged or withheld.">
      {data.map(l => !l.valid ? <Card key={l.leader_360_id} title={l.name}><div className="note">Not enough raters to report.</div></Card> : (
        <div key={l.leader_360_id} className="grid">
          <div className="grid g4">
            <Card><div className="label">Leader</div><div className="kpi" style={{ fontSize: 20 }}>{l.name}</div><div className="sub">Groups published: {l.groups_published.join(", ")}</div></Card>
            <Card><div className="label">Leadership readiness index</div><div className="kpi">{Number(l.lri).toFixed(2)}</div><div className="sub">{l.lri_band.replace(/_/g, " ")}</div></Card>
            <Card><div className="label">Fit with organisation</div><div className="kpi">{l.fit_index}</div><div className="sub">{l.fit_band}</div></Card>
            <Card><div className="label">Culture role (target <Orient o={l.target} />)</div><div style={{ marginTop: 8 }}><Verdict v={l.classification} /></div>
              <div className="pill-row" style={{ marginTop: 8 }}>{l.flags.map((f: string) => <span key={f} className="badge b-miss">{f} flag</span>)}</div></Card>
          </div>
          <div className="grid g2">
            <Card title="Self versus others" hint="Section averages, 1–5"><Leader360Chart self={l.self_avg} other={l.other_avg} gaps={l.self_other} /></Card>
            <Card title="Leader orientation profile" hint={l.team_basis}>
              <table><tbody>{OR.map(o => <tr key={o}><td><Orient o={o} /></td><td style={{ width: "60%" }}><div style={{ height: 10, width: Number(l.leader_profile[o]) * 2.2 + "%", background: "#1C2B4A", borderRadius: 3 }} /></td><td><b>{l.leader_profile[o]}</b></td></tr>)}</tbody></table>
              <div className="sub" style={{ marginTop: 10 }}>Default style: {l.default.join(", ")} · growth edge: {l.growth} · {l.counts_toward_tps ? "counts toward the TPS" : "not yet counted toward the TPS (360 window open)"}</div>
            </Card>
          </div>
        </div>))}
    </Page>
  );
}
