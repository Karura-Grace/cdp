import { useEffect, useState } from "react";
import { api, A, OR, n } from "../api";
import { Card, Page, useApi, Err, Loading, Orient, Verdict } from "../components/ui";

export default function Reassess() {
  const sc = useApi<any>(`/v1/assessments/${A}/score`);
  const plan = useApi<any>(`/v1/assessments/${A}/plan`);
  const [now, setNow] = useState<Record<string, string>>({});
  const [res, setRes] = useState<any>(null);
  const [err, setErr] = useState<any>(null);
  const [pri, setPri] = useState("");
  const [items, setItems] = useState<string[]>([]);
  const [pulse, setPulse] = useState<any>(null);
  useEffect(() => { if (sc.data) { const b = sc.data.score.orientation_scores.now; setNow({ ENGAGE: String(n(b.ENGAGE) + 4), INNOVATE: String(n(b.INNOVATE) + 5), PERFORM: String(n(b.PERFORM) - 3), GOVERN: String(n(b.GOVERN) - 6) }); } }, [sc.data]);
  useEffect(() => { if (plan.data && !pri) setPri(plan.data.priorities[0]?.priority_id); }, [plan.data]);
  if (sc.error || plan.error) return <Page title="Stage 6 · Re-assessment"><Err e={sc.error || plan.error} /></Page>;
  if (!sc.data || !plan.data) return <Loading />;
  const base = sc.data.score.orientation_scores.now;
  const sum = OR.reduce((t, o) => t + (Number(now[o]) || 0), 0);
  const check = () => api(`/v1/assessments/${A}/trade-off-check`, { method: "POST", body: { now: Object.fromEntries(OR.map(o => [o, Number(now[o])])) } }).then(r => { setErr(null); setRes(r); }).catch(setErr);
  const watch: string[] = plan.data.priorities.find((p: any) => p.priority_id === pri)?.actions?.[0]?.watchlist || [];
  const sendPulse = () => api(`/v1/assessments/${A}/pulses`, { method: "POST", body: { priority_id: pri, items } }).then(r => { setErr(null); setPulse(r); }).catch(setErr);
  return (
    <Page title="Stage 6 · Re-assessment" sub="Verify that BUILD priorities rose by releasing the planned trade-off, and configure pulse checks from each priority’s watchlist.">
      <Err e={err} />
      <Card title="Trade-off verification" hint="Enter a re-assessment NOW profile (must total 100). The baseline is the frozen cycle-1 score.">
        <table><thead><tr><th>Orientation</th><th>Baseline</th><th>Re-assessment</th><th>Change</th></tr></thead><tbody>
          {OR.map(o => <tr key={o}><td><Orient o={o} /></td><td>{base[o]}</td><td style={{ width: 160 }}><input className="f" value={now[o] || ""} onChange={e => setNow({ ...now, [o]: e.target.value })} /></td>
            <td>{(Number(now[o]) - n(base[o])).toFixed(2)}</td></tr>)}
          <tr><td><b>Total</b></td><td>100</td><td><span className={"total " + (Math.abs(sum - 100) < 1e-9 ? "good" : "bad")}>{sum.toFixed(2)}</span></td><td /></tr>
        </tbody></table>
        <button className="btn" style={{ marginTop: 10 }} onClick={check}>Verify trade-offs</button>
        {res && <div style={{ marginTop: 14 }}><table><thead><tr><th>Priority</th><th>Target</th><th>Planned release</th><th>Rise</th><th>Share from trade-off</th><th>Verdict</th></tr></thead><tbody>
          {res.verification.map((v: any) => <tr key={v.priority}><td>{v.priority}</td><td><Orient o={v.target} /></td><td><Orient o={v.trade_off} /></td><td>{v.rise}</td><td>{v.share_trade_off ?? "—"}</td>
            <td><Verdict v={v.verdict === "INTENDED_RELEASE" ? "HIT" : v.verdict === "MIXED_RELEASE" ? "PARTIAL_HIT" : "MISS"} /> {v.verdict.replace(/_/g, " ").toLowerCase()}</td></tr>)}
        </tbody></table>
          {res.unintended_release.length > 0 && <div className="err" style={{ marginTop: 8 }}>Unintended release of protected orientations: {res.unintended_release.join(", ")}</div>}</div>}
      </Card>
      <Card title="Pulse check" hint="Up to 10 items, all drawn from the selected priority’s watchlist.">
        <select className="f" style={{ maxWidth: 360 }} value={pri} onChange={e => { setPri(e.target.value); setItems([]); }}>
          {plan.data.priorities.map((p: any) => <option key={p.priority_id} value={p.priority_id}>{p.priority_id} · {p.classification} {p.orientation}</option>)}</select>
        <div className="pill-row" style={{ marginTop: 12 }}>{watch.map(w => <label key={w} className={"badge " + (items.includes(w) ? "b-navy" : "b-neutral")} style={{ cursor: "pointer" }}>
          <input type="checkbox" style={{ display: "none" }} checked={items.includes(w)} onChange={() => setItems(items.includes(w) ? items.filter(x => x !== w) : [...items, w])} />{w}</label>)}</div>
        <button className="btn" style={{ marginTop: 12 }} disabled={!items.length} onClick={sendPulse}>Schedule pulse ({items.length})</button>
        {pulse && <div className="ok" style={{ marginTop: 10 }}>{pulse.status}: {pulse.items.join(", ")}</div>}
      </Card>
    </Page>
  );
}
