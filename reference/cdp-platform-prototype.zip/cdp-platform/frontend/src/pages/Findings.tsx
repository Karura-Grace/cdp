import { A, pretty } from "../api";
import { Card, Page, useApi, Err, Loading, Orient, Verdict } from "../components/ui";

const CHECKS: [string, string, string][] = [["C1", "Performance alignment", "Does the culture support the strategic priorities?"], ["C2", "Leadership behaviour", "Does the culture reward the leadership the strategy needs?"],
  ["C3", "Stop / start", "Do the behaviours the organisation must stop still dominate?"], ["C4", "Business-model readiness", "Does the culture fit the business model?"]];

export default function Findings() {
  const { data, error } = useApi<any>(`/v1/assessments/${A}/findings`);
  if (error) return <Page title="Stage 4 · Findings"><Err e={error} /></Page>;
  if (!data) return <Loading />;
  const metric = (c: string) => c === "C1" ? data.c1.map((x: any) => x.metrics.alignment_pct + "%").join(" · ") : c === "C4" ? data.c4.metrics.alignment_pct + "%"
    : c === "C2" ? `rank ${data.c2.metrics.rank} · gap ${data.c2.metrics.behaviour_gap_points} · ${data.c2.metrics.intensity}` : `${data.c3.metrics.moderate_count} MODERATE dominants`;
  return (
    <Page title="Stage 4 · Findings" sub="Deterministic results of the strategic checks and the scenario library. Findings are linked to plan priorities.">
      <div className="grid g4">
        {CHECKS.map(([c, t, d]) => <div key={c} className={"card tile " + data.checks[c]}>
          <div className="label">{c} · {t}</div><div style={{ margin: "10px 0" }}><Verdict v={data.checks[c]} /></div>
          <div className="kpi" style={{ fontSize: 18 }}>{metric(c)}</div><div className="sub">{d}</div></div>)}
      </div>
      <Card title="Scenarios matched" hint="Patterns from the scenario library, in severity order">
        <div className="grid g3">{data.scenarios.map((s: any) => <div key={s.scenario_id} className="card" style={{ background: "#FAFBFD" }}>
          <div style={{ display: "flex", justifyContent: "space-between" }}><b>{s.scenario_id} · {s.name}</b><Verdict v={s.severity} /></div>
          <p style={{ fontSize: 14 }}>{s.diagnosis}</p>
          <div className="label">Questions to test</div><ul style={{ fontSize: 13.5, paddingLeft: 18 }}>{s.hypotheses.map((h: string) => <li key={h}>{h}</li>)}</ul>
          <div className="label">Risks if ignored</div><ul style={{ fontSize: 13.5, paddingLeft: 18 }}>{s.risks.map((h: string) => <li key={h}>{h}</li>)}</ul></div>)}</div>
      </Card>
      <Card title="All findings">
        <table><thead><tr><th>ID</th><th>Type</th><th>Orientation</th><th>Verdict</th><th>Severity</th><th>Key metric</th></tr></thead><tbody>
          {data.findings.map((f: any) => <tr key={f.finding_id}><td>{f.finding_id}</td><td>{pretty(f.type)}</td><td>{(f.orientation || []).map((o: string) => <div key={o}><Orient o={o} /></div>)}</td>
            <td><Verdict v={f.verdict} /></td><td><Verdict v={f.severity} /></td>
            <td style={{ fontSize: 12.5 }}>{Object.entries(f.metrics || {}).filter(([, v]) => typeof v !== "object").map(([k, v]) => `${k.replace(/_/g, " ")} ${v}`).join(" · ")}
              {f.evidence?.overrides?.length ? <div style={{ color: "#A93226" }}>{f.evidence.overrides.join(", ")}</div> : null}</td></tr>)}
        </tbody></table>
      </Card>
    </Page>
  );
}
