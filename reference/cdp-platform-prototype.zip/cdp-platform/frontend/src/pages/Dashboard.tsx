import { A } from "../api";
import { Card, Page, useApi, Err, Loading, Orient, Verdict } from "../components/ui";

export default function Dashboard() {
  const { data, error } = useApi<any>("/v1/dashboards/executive", { a_id: A });
  if (error) return <Page title="Executive dashboard"><Err e={error} /></Page>;
  if (!data) return <Loading />;
  const tot = data.priorities.reduce((t: any, p: any) => ({ a: t.a + p.actions, pub: t.pub + p.published, c: t.c + p.closed }), { a: 0, pub: 0, c: 0 });
  return (
    <Page title="Executive dashboard" sub="Implementation status by priority. RAG combines milestones, KPI direction and evidence.">
      <div className="grid g4">
        <Card><div className="label">Priorities</div><div className="kpi">{data.priorities.length}</div></Card>
        <Card><div className="label">Actions</div><div className="kpi">{tot.a}</div></Card>
        <Card><div className="label">Published or later</div><div className="kpi">{tot.pub}</div></Card>
        <Card><div className="label">Closed</div><div className="kpi">{tot.c}</div></Card>
      </div>
      {data.priority_zero && <Card title="Priority zero"><div className="pill-row">{data.priority_zero.items.map((i: any) =>
        <span key={i.finding_id} className={"badge " + (data.p0_complete.includes(i.finding_id) ? "b-hit" : "b-partial")}>{data.p0_complete.includes(i.finding_id) ? "✓" : "◐"} {i.item}</span>)}</div></Card>}
      <Card title="Priorities">
        <table><thead><tr><th>#</th><th>Orientation</th><th>Classification</th><th>Owner</th><th>Due</th><th>Progress</th><th>RAG</th></tr></thead><tbody>
          {data.priorities.map((p: any) => <tr key={p.priority_id}><td>{p.priority_id}</td><td><Orient o={p.orientation} /></td><td>{p.classification}</td><td>{p.owner_role}</td><td>{p.due}</td>
            <td style={{ width: 220 }}><div style={{ height: 8, background: "#EEF1F6", borderRadius: 4 }}><div style={{ height: 8, width: (p.actions ? (p.published / p.actions) * 100 : 0) + "%", background: "#1C2B4A", borderRadius: 4 }} /></div>
              <span className="sub" style={{ fontSize: 12 }}>{p.published}/{p.actions} live · {p.closed} closed</span></td>
            <td>{p.rag ? <Verdict v={p.rag} /> : <span className="sub">not started</span>}</td></tr>)}
        </tbody></table>
      </Card>
    </Page>
  );
}
