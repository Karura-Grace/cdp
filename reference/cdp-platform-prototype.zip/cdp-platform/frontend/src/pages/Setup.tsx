import { useState } from "react";
import { api, A, E, ApiError } from "../api";
import { Card, Page, useApi, Err, Loading, Verdict, Orient } from "../components/ui";
import { useUser, isConsultant } from "../App";

const TITLES: Record<string, string> = { A: "A · Organisation profile", B: "B · Strategy and priorities", C: "C · Performance scorecard", D: "D · Vision and ambition",
  E: "E · Current challenges", F: "F · Leadership expectations", G: "G · Stop / start / protect", H: "H · People systems", I: "I · Fielding design" };

function Value({ v }: { v: any }) {
  if (v === null || v === undefined) return <span style={{ color: "#5A6478" }}>—</span>;
  if (Array.isArray(v)) return <ul style={{ margin: 0, paddingLeft: 18 }}>{v.map((x, i) => <li key={i}>{typeof x === "object" ? Object.entries(x).map(([k, y]) => `${k}: ${y}`).join(" · ") : String(x)}</li>)}</ul>;
  if (typeof v === "object") return <span>{JSON.stringify(v)}</span>;
  return <span>{String(v)}</span>;
}

export default function Setup() {
  const u = useUser();
  const sec = useApi<any[]>(`/v1/engagements/${E}/setup`);
  const req = useApi<any>(`/v1/engagements/${E}/requirements`);
  const [pf, setPf] = useState<any>(null);
  const [edit, setEdit] = useState<{ section: string; text: string } | null>(null);
  const [err, setErr] = useState<ApiError | null>(null);
  if (sec.error) return <Err e={sec.error} />;
  if (!sec.data) return <Loading />;
  const save = async () => {
    if (!edit) return;
    try { await api(`/v1/engagements/${E}/setup/${edit.section}`, { method: "PUT", body: { payload: JSON.parse(edit.text) } }); setEdit(null); sec.reload(); req.reload(); }
    catch (e: any) { setErr(e instanceof ApiError ? e : new ApiError(422, { title: "Invalid JSON" })); }
  };
  const runPf = () => api(`/v1/assessments/${A}/preflight`, { method: "POST" }).then(setPf).catch(setErr);
  return (
    <Page title="Stage 1 · Setup" sub="Executive workshop inputs. Sections B–I are agreed before launch and locked once fielding starts."
      actions={isConsultant(u) && <button className="btn orange" onClick={runPf}>Run launch checks</button>}>
      <Err e={err} />
      {pf && <Card title={pf.pass ? "Launch checks passed" : "Launch blocked"} right={<Verdict v={pf.pass ? "HIT" : "MISS"} />}>
        <table><tbody>{pf.checks.map((c: any) => <tr key={c.id}><td style={{ width: 50 }}><b>{c.id}</b></td><td>{c.check}</td><td style={{ width: 90 }}><Verdict v={c.pass ? "HIT" : "MISS"} /></td></tr>)}</tbody></table>
      </Card>}
      {req.data && <Card title="Derived requirements" hint="Computed by the rules engine from Sections B and F. These drive checks C1, C2 and C4.">
        <div className="grid g3">
          <div><div className="label">C1 performance requirements</div>
            {req.data.c1_requirements.map((r: any) => <div key={r.requirement_id} style={{ marginTop: 8 }}><b>{r.requirement_id}</b> {r.type} · {r.goal_type.replace(/_/g, " ").toLowerCase()}<br />
              {Object.entries(r.thresholds).map(([o, t]) => <span key={o} style={{ marginRight: 10 }}><Orient o={o} /> ≥ {String(t)}</span>)}</div>)}</div>
          <div><div className="label">C4 business-model requirement</div><div style={{ marginTop: 8 }}>{req.data.c4_requirement.model} · {req.data.c4_requirement.type}<br />
            {Object.entries(req.data.c4_requirement.thresholds || {}).map(([o, t]) => <span key={o} style={{ marginRight: 10 }}><Orient o={o} /> ≥ {String(t)}</span>)}</div></div>
          <div><div className="label">Leadership target</div><div className="kpi" style={{ fontSize: 22, marginTop: 6 }}><Orient o={req.data.leadership_target_orientation} /></div><div className="sub">Resolved from Section F behaviour tags</div></div>
        </div>
      </Card>}
      <div className="grid g2">
        {sec.data.sort((a, b) => a.section.localeCompare(b.section)).map(s => (
          <Card key={s.section} title={TITLES[s.section] || s.section} hint={s.workshop_date ? `Workshop ${s.workshop_date} · ${s.participants.join(", ")}` : "Not yet agreed"}
            right={<span className={"badge " + (s.status === "AGREED" ? "b-hit" : "b-partial")}>{s.status}</span>}>
            {edit?.section === s.section ? <div>
              <textarea style={{ minHeight: 220, fontFamily: "monospace", fontSize: 12.5 }} value={edit?.text ?? ""} onChange={e => setEdit({ section: s.section, text: e.target.value })} />
              <div style={{ display: "flex", gap: 8, marginTop: 8 }}><button className="btn" onClick={save}>Save draft</button><button className="btn alt" onClick={() => setEdit(null)}>Cancel</button></div>
            </div> : <table><tbody>{Object.entries(s.payload).map(([k, v]) => <tr key={k}><td style={{ width: 90 }}><b>{k.toUpperCase()}</b></td><td><Value v={v} /></td></tr>)}</tbody></table>}
            {u.role !== "EXECUTIVE" && !edit && <button className="btn alt" style={{ marginTop: 10 }} onClick={() => setEdit({ section: s.section, text: JSON.stringify(s.payload, null, 2) })}>Edit</button>}
          </Card>))}
      </div>
    </Page>
  );
}
