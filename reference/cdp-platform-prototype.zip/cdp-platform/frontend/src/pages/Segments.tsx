import { useState } from "react";
import { A, OR, OC, n } from "../api";
import { Card, Page, useApi, Err, Loading, Orient } from "../components/ui";

const shade = (d: number, o: string) => { const a = Math.min(1, Math.abs(d) / 10); return d >= 0 ? OC[o] + Math.round(a * 200 + 30).toString(16).padStart(2, "0") : "#B03A2E" + Math.round(a * 140 + 20).toString(16).padStart(2, "0"); };

export default function Segments() {
  const [axis, setAxis] = useState("department");
  const { data, error } = useApi<any>(`/v1/assessments/${A}/segments`, { axis });
  return (
    <Page title="Segment analysis" sub="Cells are differences from the organisation profile (NOW). Groups below five respondents are suppressed; every query is logged."
      actions={<select className="f" style={{ width: 200 }} value={axis} onChange={e => setAxis(e.target.value)}>
        <option value="department">Department</option><option value="grade">Grade</option><option value="tenure_band">Tenure band</option></select>}>
      <Err e={error} />
      {!data ? <Loading /> : <Card title={"By " + axis.replace("_", " ")}>
        <table className="heat"><thead><tr><th>Segment</th><th>n</th>{OR.map(o => <th key={o}><Orient o={o} /></th>)}<th>SDI</th><th>Sub-culture</th><th>eOS</th></tr></thead><tbody>
          <tr><td><b>Organisation</b></td><td>—</td>{OR.map(o => <td key={o} className="cell">{data.organisation[o]}</td>)}<td /><td /><td /></tr>
          {data.segments.map((s: any) => s.suppressed
            ? <tr key={s.segment}><td>{s.label}</td><td colSpan={8} style={{ color: "#5A6478" }}>Suppressed · {s.reason}</td></tr>
            : <tr key={s.segment}><td>{s.label}</td><td>{s.n}</td>
              {OR.map(o => <td key={o} className="cell" style={{ background: shade(n(s.diff[o]), o), color: Math.abs(n(s.diff[o])) > 6 ? "#fff" : "#1F2633" }}>{n(s.diff[o]) > 0 ? "+" : ""}{s.diff[o]}</td>)}
              <td>{s.subculture.sdi}</td><td>{s.subculture.is_subculture ? <span className="badge b-partial">Sub-culture{s.subculture.significance ? " · p " + s.subculture.significance : ""}</span> : "—"}</td>
              <td>{s.eos_index ?? "—"}</td></tr>)}
        </tbody></table>
      </Card>}
    </Page>
  );
}
