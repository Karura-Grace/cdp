import { useState } from "react";
import { api, A } from "../api";
import { Card, Page, useApi, Err, Loading, Verdict } from "../components/ui";
import { ProfileChart, Gauge } from "../components/charts";
import { useUser, isConsultant } from "../App";

const SECTIONS: [string, string][] = [["what_this_means", "What this means"], ["what_to_do_next", "What to do next"]];

export default function Reports() {
  const u = useUser();
  const [typ, setTyp] = useState("ORGANISATIONAL");
  const rep = useApi<any>(`/v1/assessments/${A}/reports/${typ}`);
  const [text, setText] = useState<Record<string, string>>({});
  const [guard, setGuard] = useState<Record<string, string[]>>({});
  const [err, setErr] = useState<any>(null);
  const draft = async () => { setErr(null);
    try { const r = await api<any>(`/v1/assessments/${A}/reports/${typ}/draft`, { method: "POST" }); setText(r.sections); setGuard(r.guardrails); rep.reload(); } catch (e) { setErr(e); } };
  const accept = (k: string) => api(`/v1/assessments/${A}/reports/${typ}/accept`, { method: "POST", body: { section: k, text: text[k] ?? rep.data.sections[k] } })
    .then(() => { setErr(null); rep.reload(); }).catch(setErr);
  const release = () => api(`/v1/assessments/${A}/reports/${typ}/release`, { method: "POST" }).then(() => rep.reload()).catch(setErr);
  const r = rep.data;
  const tabs = <div className="pill-row">{["ORGANISATIONAL", "BOARD_SUMMARY"].map(t => <button key={t} className={"btn " + (t === typ ? "" : "alt")} onClick={() => setTyp(t)}>{t.replace("_", " ")}</button>)}</div>;
  if (rep.error) return <Page title="Stage 4 · Reports" actions={tabs}><Err e={rep.error} /></Page>;
  if (!r) return <Loading />;
  const s = r.score;
  return (
    <Page title="Stage 4 · Reports" sub={`${r.type.replace("_", " ")} · ${r.status}${r.released_by ? ` by ${r.released_by} on ${r.released_at?.slice(0, 10)}` : ""} · payload ${r.payload_hash.slice(0, 18)}…`} actions={tabs}>
      <Err e={err} />
      {isConsultant(u) && r.status !== "RELEASED" && <div className="note">AI drafting produces template narrative only. Every number is checked against the score object, causal language and restricted terminology are blocked, and a consultant must accept each section before release.
        <div style={{ display: "flex", gap: 8, marginTop: 10 }}><button className="btn" onClick={draft}>Draft narrative</button><button className="btn orange" onClick={release}>Release report</button></div></div>}
      <Card title="Executive judgement" right={<div className="pill-row">{Object.entries(r.checks).map(([c, v]: any) => <span key={c}><b style={{ fontSize: 12 }}>{c}</b> <Verdict v={v} /></span>)}</div>}>
        <div className="grid g2"><ProfileChart now={s.orientation_scores.now} pref={s.orientation_scores.preferred} />
          <div style={{ display: "flex", justifyContent: "center", alignItems: "center" }}><Gauge value={Number(s.readiness.tps)} label={s.readiness.tps_band.replace(/_/g, " ")} provisional={s.readiness.provisional} coverage={Number(s.readiness.coverage)} /></div></div>
      </Card>
      {SECTIONS.map(([k, label]) => <Card key={k} title={label} right={r.accepted?.[k] ? <span className="badge b-hit">✓ Accepted</span> : <span className="badge b-partial">Not accepted</span>}>
        {isConsultant(u) && r.status !== "RELEASED"
          ? <><textarea style={{ minHeight: 120 }} value={text[k] ?? r.sections[k] ?? ""} onChange={e => setText({ ...text, [k]: e.target.value })} placeholder="Draft the narrative first" />
            {guard[k]?.length ? <div className="err" style={{ marginTop: 8 }}>{guard[k].join(" · ")}</div> : null}
            <button className="btn" style={{ marginTop: 8 }} disabled={!(text[k] ?? r.sections[k])} onClick={() => accept(k)}>Accept section</button></>
          : <p style={{ fontSize: 14.5, lineHeight: 1.6 }}>{r.sections[k] || "—"}</p>}
      </Card>)}
      {r.plan && <Card title="Recommended priorities">
        <table><thead><tr><th>#</th><th>Orientation</th><th>Classification</th><th>Urgency</th><th>Owner</th><th>Due</th></tr></thead><tbody>
          {r.plan.priority_zero && <tr><td>0</td><td colSpan={3}>{r.plan.priority_zero.items.map((i: any) => i.item).join("; ")}</td><td>{r.plan.priority_zero.owner_role}</td><td>{r.plan.priority_zero.due}</td></tr>}
          {r.plan.priorities.map((p: any) => <tr key={p.priority_id}><td>{p.sequence}</td><td>{p.orientation}</td><td>{p.classification}</td><td>{p.urgency_tier.replace(/_/g, " ")}</td><td>{p.owner_role}</td><td>{p.due}</td></tr>)}
        </tbody></table></Card>}
    </Page>
  );
}
