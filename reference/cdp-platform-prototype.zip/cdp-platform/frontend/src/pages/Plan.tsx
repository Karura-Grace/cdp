import { useState } from "react";
import { api, A, ApiError } from "../api";
import { Card, Page, useApi, Err, Loading, Orient, Verdict, pretty } from "../components/ui";
import { useUser, isConsultant } from "../App";

const NEXT: Record<string, [string, string[]][]> = {
  DRAFT: [["IN_REVIEW", ["PAC_CONSULTANT"]], ["DISCARDED", ["PAC_CONSULTANT"]]],
  IN_REVIEW: [["IN_CO_DESIGN", ["PAC_CONSULTANT"]]],
  IN_CO_DESIGN: [["APPROVED", ["EXECUTIVE", "PEOPLE_LEADER"]]],
  APPROVED: [["PUBLISHED", ["PAC_CONSULTANT"]]],
  PUBLISHED: [["IN_PROGRESS", ["PEOPLE_LEADER", "CLIENT_ADMIN", "EXECUTIVE"]]],
  IN_PROGRESS: [["UNDER_REVIEW", ["PEOPLE_LEADER", "CLIENT_ADMIN", "EXECUTIVE"]]],
  UNDER_REVIEW: [["IN_PROGRESS", ["EXECUTIVE", "PEOPLE_LEADER", "PAC_CONSULTANT"]], ["CLOSED", ["EXECUTIVE", "PEOPLE_LEADER"]], ["RETIRED", ["EXECUTIVE", "PEOPLE_LEADER", "PAC_CONSULTANT"]]],
};

function ActionRow({ a, onChange, role }: { a: any; onChange: () => void; role: string }) {
  const [open, setOpen] = useState(false);
  const [f, setF] = useState<any>({ owner: a.owner || "", sponsor: a.sponsor || "", kpi: a.kpi || "", baseline_value: a.baseline_value ?? "", target_value: a.target_value ?? "", start_date: a.start_date, end_date: a.end_date, effort: a.effort });
  const [err, setErr] = useState<ApiError | null>(null);
  const [note, setNote] = useState("");
  const go = (to: string) => { const reason = to === "DISCARDED" || to === "RETIRED" ? prompt("Reason") || undefined : undefined;
    api(`/v1/actions/${a.action_id}/transition`, { method: "POST", body: { to, reason } }).then(() => { setErr(null); onChange(); }).catch(setErr); };
  const save = () => api(`/v1/actions/${a.action_id}`, { method: "PATCH", body: { ...f, effort: Number(f.effort), baseline_value: f.baseline_value === "" ? null : Number(f.baseline_value), target_value: f.target_value === "" ? null : Number(f.target_value) } })
    .then(() => { setErr(null); onChange(); }).catch(setErr);
  const addEv = () => note && api(`/v1/actions/${a.action_id}/evidence`, { method: "POST", body: { type: "NOTE", note } }).then(() => { setNote(""); onChange(); }).catch(setErr);
  return (<>
    <tr>
      <td><b>{a.action_id}</b><div className="sub" style={{ fontSize: 11.5 }}>{({ QUICK_WIN_0_3M: "Quick win · 0–3 months", MEDIUM_3_12M: "Medium term · 3–12 months", STRUCTURAL_12M_PLUS: "Structural · 12 months +" } as any)[a.horizon] || pretty(a.horizon)}</div></td>
      <td>{a.intervention}{a.is_visible_signal && <span className="badge b-orange" style={{ marginLeft: 6 }}>30-day signal</span>}<div className="sub" style={{ fontSize: 12 }}>{pretty(a.system_lever)} · {a.objective}</div></td>
      <td>{a.priority_score}<div className="sub" style={{ fontSize: 11.5 }}>I{a.impact}·U{a.urgency}·E{a.effort}</div></td>
      <td><span className="badge b-navy">{a.status.replace(/_/g, " ")}</span>{a.rag && <div style={{ marginTop: 4 }}><Verdict v={a.rag} /></div>}</td>
      <td><div className="pill-row">{(NEXT[a.status] || []).filter(([, r]) => r.includes(role)).map(([to]) => <button key={to} className="btn alt" style={{ padding: "5px 9px", fontSize: 12 }} onClick={() => go(to)}>→ {to.replace(/_/g, " ").toLowerCase()}</button>)}
        <button className="btn alt" style={{ padding: "5px 9px", fontSize: 12 }} onClick={() => setOpen(!open)}>{open ? "Close" : "Edit"}</button></div></td>
    </tr>
    {(open || err) && <tr><td colSpan={5} style={{ background: "#FAFBFD" }}>
      <Err e={err} />
      {open && <><div className="grid g4" style={{ marginTop: 8 }}>
        {(["owner", "sponsor", "kpi", "baseline_value", "target_value", "start_date", "end_date", "effort"] as const).map(k => <label key={k} className="label">{k.replace("_", " ")}
          {k === "effort" ? <select className="f" value={f.effort} onChange={e => setF({ ...f, effort: e.target.value })}>{[1, 2, 3, 4, 5].map(v => <option key={v}>{v}</option>)}</select>
            : <input className="f" type={k.endsWith("date") ? "date" : "text"} value={f[k]} onChange={e => setF({ ...f, [k]: e.target.value })} />}</label>)}
      </div>
      <div style={{ display: "flex", gap: 8, marginTop: 10, alignItems: "center" }}><button className="btn" onClick={save}>Save</button>
        <input className="f" style={{ maxWidth: 360 }} placeholder="Evidence note" value={note} onChange={e => setNote(e.target.value)} /><button className="btn alt" onClick={addEv}>Add evidence ({a.evidence_count})</button></div>
      <div className="sub" style={{ fontSize: 12, marginTop: 8 }}>Pulse watchlist: {(a.watchlist || []).join(", ")} · reviews {(a.review_points || []).join(", ")}
        {a.events?.length ? " · history: " + a.events.map((e: any) => `${e.to} (${e.actor})`).join(" → ") : ""}</div></>}
    </td></tr>}
  </>);
}

export default function Plan() {
  const u = useUser();
  const plan = useApi<any>(`/v1/assessments/${A}/plan`);
  const acts = useApi<any[]>(`/v1/assessments/${A}/actions`);
  const [err, setErr] = useState<any>(null);
  const reload = () => { plan.reload(); acts.reload(); };
  const gen = () => api(`/v1/assessments/${A}/plan`, { method: "POST" }).then(reload).catch(setErr);
  const done = (id: string) => api(`/v1/assessments/${A}/plan/priority-zero/complete`, { method: "POST", body: { finding_id: id } }).then(reload).catch(setErr);
  const actions = isConsultant(u) && <button className="btn orange" onClick={gen}>{plan.data ? "Regenerate plan" : "Generate plan"}</button>;
  if (plan.error) return <Page title="Stage 5 · Action plan" actions={actions}><Err e={err} /><div className="note">No plan yet. Score the assessment, then generate the plan.</div></Page>;
  if (!plan.data || !acts.data) return <Loading />;
  const p = plan.data;
  return (
    <Page title="Stage 5 · Action plan" sub={`Priority cap ${p.cap} (set by the TPS) · actions are ranked by impact × urgency ÷ effort`} actions={actions}>
      <Err e={err} />
      {p.priority_zero && <Card title="Priority zero · pre-conditions" hint={`Owner ${p.priority_zero.owner_role} · due ${p.priority_zero.due}. Actions under blocked priorities cannot be published until these are complete.`}>
        <table><tbody>{p.priority_zero.items.map((i: any) => { const ok = p.p0_complete.includes(i.finding_id);
          return <tr key={i.finding_id}><td>{i.item}</td><td style={{ width: 90 }}>{i.finding_id}</td><td style={{ width: 160 }}>{ok ? <Verdict v="HIT" /> : isConsultant(u) ? <button className="btn alt" onClick={() => done(i.finding_id)}>Mark complete</button> : <Verdict v="PARTIAL_HIT" />}</td></tr>; })}</tbody></table>
      </Card>}
      {p.priorities.map((pr: any) => <Card key={pr.priority_id} title={`Priority ${pr.sequence} · ${pr.classification} ${pr.orientation}`}
        hint={`${pr.urgency_tier.replace(/_/g, " ")} · gap ${pr.gap} · owner ${pr.owner_role} · due ${pr.due}${pr.blocked_by?.length ? " · gated by " + pr.blocked_by.join(", ") : ""}`}
        right={<div className="pill-row"><Orient o={pr.orientation} />{pr.trade_off_orientation && <span className="badge b-neutral">trade-off: {pr.trade_off_orientation}</span>}{pr.c3_levers && <span className="badge b-orange">C3 levers</span>}</div>}>
        {pr.pathway?.from ? <div className="note" style={{ marginBottom: 12 }}><b>Pathway</b> {pr.pathway.from} → {pr.pathway.to} · {pretty(pr.pathway.relationship)} · {pr.pathway.difficulty.toLowerCase()}
          {pr.pathway.stepping_stone && <> · via <b>{pr.pathway.stepping_stone}</b></>}<br /><i>{pr.pathway.narrative}</i> {pr.pathway.interventions}</div>
          : <div className="note" style={{ marginBottom: 12 }}><b>{pretty(pr.pathway?.relationship || "REINFORCE")} · {pr.orientation}</b> · {pr.pathway?.narrative || "No orientation shift required."}</div>}
        <table><thead><tr><th>Action</th><th>Intervention</th><th>Score</th><th>Status</th><th /></tr></thead><tbody>
          {acts.data!.filter(a => a.priority_id === pr.priority_id).map(a => <ActionRow key={a.action_id} a={a} role={u.role} onChange={reload} />)}
        </tbody></table>
      </Card>)}
      {p.backlog?.length > 0 && <Card title="Backlog (over the cap)"><ul>{p.backlog.map((b: any, i: number) => <li key={i}>{b.orientation} · {b.classification}</li>)}</ul></Card>}
    </Page>
  );
}
