import { useEffect, useState } from "react";
import { api, setToken, User } from "../api";

export default function Login({ onLogin }: { onLogin: (u: User) => void }) {
  const [users, setUsers] = useState<{ email: string; name: string; role: string }[]>([]);
  const [err, setErr] = useState("");
  useEffect(() => { api("/v1/auth/demo-users").then(setUsers).catch(() => setErr("The API is not reachable. Start the backend on port 8000.")); }, []);
  const go = async (email: string) => {
    try { const r = await api<{ token: string; user: User }>("/v1/auth/login", { method: "POST", body: { email } }); setToken(r.token); onLogin(r.user); }
    catch (e: any) { setErr(e.message); }
  };
  return (
    <div className="login">
      <div className="head"><div className="brand">PRIORITY ACTIVATOR CONSULTING</div><h2 style={{ margin: "8px 0 4px" }}>Culture Dynamics Profile</h2>
        <div style={{ color: "#c9d3e6", fontSize: 14 }}>Demonstration environment · choose a user to sign in</div></div>
      <div className="body">
        {err && <div className="err" style={{ marginBottom: 12 }}>{err}</div>}
        {users.map(u => <button key={u.email} className="userbtn" onClick={() => go(u.email)}>
          <span><b>{u.name}</b><br /><span style={{ fontSize: 12.5, color: "#5A6478" }}>{u.email}</span></span>
          <span className="badge b-neutral">{u.role.replace(/_/g, " ")}</span></button>)}
        <div className="hint" style={{ fontSize: 12.5, color: "#5A6478", marginTop: 12 }}>Production uses SSO (OIDC / SAML) with MFA for PAC roles. Survey links: /survey/demo-token-1 … demo-token-5.</div>
      </div>
    </div>
  );
}
