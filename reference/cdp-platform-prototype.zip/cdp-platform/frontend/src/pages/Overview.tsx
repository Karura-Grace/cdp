import { Link } from "react-router-dom";
import { E, A } from "../api";
import { Card, Page, useApi, Err, Loading, Verdict } from "../components/ui";

const STATES = ["SETUP", "FIELDING", "SCORING", "REPORTING", "DEBRIEF", "PLANNING", "IMPLEMENTATION", "REASSESSMENT"];
const LABEL: Record<string, string> = { SETUP: "1 Setup", FIELDING: "2 Assessment", SCORING: "3 Scoring", REPORTING: "4 Reporting", DEBRIEF: "4 Debrief", PLANNING: "5 Planning", IMPLEMENTATION: "5 Implementation", REASSESSMENT: "6 Re-assessment" };

export default function Overview() {
  const { data, error } = useApi<any[]>("/v1/engagements");
  const mon = useApi<any>(`/v1/assessments/${A}/monitor`);
  if (error) return <Err e={error} />;
  if (!data) return <Loading />;
  const e = data.find(x => x.id === E) || data[0];
  const cur = STATES.indexOf(e.state);
  return (
    <Page title={e.tenant.name} sub={`Engagement ${e.id} · cycle ${e.cycle_no} · ${e.tenant.sector.replace(/_/g, " ").toLowerCase()} · ${e.tenant.headcount} staff`}>
      <Card title="Engagement lifecycle" hint="Each stage gates the next. The platform follows setup → assessment → scoring → reporting → advisory → re-assessment.">
        <div className="stepper">{STATES.map((s, i) => <div key={s} className={"step " + (i < cur ? "done" : i === cur ? "cur" : "")}>{LABEL[s]}</div>)}</div>
      </Card>
      <div className="grid g4">
        <Card><div className="label">State</div><div className="kpi" style={{ fontSize: 22 }}>{e.state}</div></Card>
        <Card><div className="label">Assessment</div><div className="kpi" style={{ fontSize: 22 }}>{e.assessment?.status}</div><div className="sub">{e.assessment?.window_open} → {e.assessment?.window_close}</div></Card>
        <Card><div className="label">Responses</div><div className="kpi">{mon.data?.submitted ?? "—"}<small>of {mon.data?.invited ?? "—"}</small></div></Card>
        <Card><div className="label">Privacy</div><div className="kpi" style={{ fontSize: 18 }}>{e.tenant.privacy_regime}</div><div className="sub">Residency {e.tenant.residency_region}</div></Card>
      </div>
      <Card title="Where to go next">
        <table><tbody>
          {[["/setup", "Stage 1 · Setup", "Strategic context, scorecard, leadership and system inputs agreed in workshop; derived requirements and launch checks."],
            ["/fielding", "Stage 2 · Assessment", "Monitor fielding, preview the employee survey, freeze the response set."],
            ["/scoring", "Stage 3 · Scoring", "Run the deterministic scoring engine; profiles, gaps, readiness, eOS, perception gaps, data quality."],
            ["/findings", "Stage 4 · Findings & reports", "Strategic checks C1–C4, scenarios, narrative drafting with guardrails, release."],
            ["/plan", "Stage 5 · Advisory", "Priority zero, priorities, pathways, generated actions and the approval workflow."],
            ["/reassess", "Stage 6 · Re-assessment", "Trade-off verification and pulse configuration."]].map(([to, t, d]) =>
            <tr key={to}><td style={{ width: 240 }}><Link to={to}><b>{t}</b></Link></td><td>{d}</td><td style={{ width: 90 }}><Verdict v={to === "/setup" && cur > 0 ? "HIT" : undefined} /></td></tr>)}
        </tbody></table>
      </Card>
    </Page>
  );
}
