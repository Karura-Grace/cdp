import { useState } from "react";
import { api, A, OR, n } from "../api";
import { Card, Page, useApi, Err, Loading, Orient, Verdict } from "../components/ui";
import { ProfileChart, GapChart, Gauge, GaugeNote, PerceptionChart, EosChart } from "../components/charts";
import { useUser, isConsultant } from "../App";

export default function Scoring() {
  const u = useUser();
  const sc = useApi<any>(`/v1/assessments/${A}/score`);
  const [err, setErr] = useState<any>(null);
  const run = (path: string) => api(`/v1/assessments/${A}/${path}`, { method: "POST" }).then(() => sc.reload()).catch(setErr);
  const actions = isConsultant(u) && <div style={{ display: "flex", gap: 8 }}>
    <button className="btn alt" onClick={() => run("freeze")}>Freeze responses</button>
    <button className="btn" onClick={() => run("score")}>Run scoring</button>
    <button className="btn orange" disabled={!sc.data || sc.data.frozen} onClick={() => run("score/freeze")}>Freeze score</button></div>;
  if (sc.error) return <Page title="Stage 3 · Scoring" actions={actions}><Err e={err || sc.error} /><div className="note">Freeze the response set, then run scoring.</div></Page>;
  if (!sc.data) return <Loading />;
  const s = sc.data.score, os = s.orientation_scores, r = s.readiness;
  return (
    <Page title="Stage 3 · Scoring" sub={`Score v${sc.data.score_version} · rules ${s.rules_version} · ${sc.data.payload_hash.slice(0, 20)}… ${sc.data.frozen ? "· FROZEN" : ""}`} actions={actions}>
      <Err e={err} />
      <div className="grid g4">
        <Card><div className="label">Dominant</div><div className="kpi" style={{ fontSize: 22 }}>{s.dominance.dominant.map((o: string) => <Orient key={o} o={o} />)}</div><div className="sub">{s.dominance.shared ? "Shared dominance" : "Secondary " + s.dominance.secondary}</div></Card>
        <Card><div className="label">Culture strength</div><div className="kpi">{s.culture_strength}</div><div className="sub">{s.strength_band}</div></Card>
        <Card><div className="label">Congruence</div><div className="kpi">{s.congruence.dimension_pct}%</div><div className="sub">{s.congruence.band.replace(/_/g, " ")}</div></Card>
        <Card><div className="label">Included responses</div><div className="kpi">{s.counts.now}<small>NOW</small></div><div className="sub">{s.counts.preferred} with PREFERRED</div></Card>
      </div>
      <div className="grid g2">
        <Card title="Culture profile" hint="Organisation means across D1–D6, NOW and PREFERRED"><ProfileChart now={os.now} pref={os.preferred} /></Card>
        <Card title="Gap classification" hint="BUILD ≥ 8 · STRENGTHEN 4 to < 8 · KEEP & PROTECT within ±4 · MODERATE ≤ −4"><GapChart gap={os.gap} cls={s.classification} /></Card>
      </div>
      <Card title="Dimension profiles (NOW)">
        <table><thead><tr><th>Dimension</th>{OR.map(o => <th key={o}><Orient o={o} /></th>)}<th>Dominant</th></tr></thead><tbody>
          {Object.entries(s.dimension_now).map(([d, p]: any) => { const dom = OR.reduce((a, b) => n(p[a]) >= n(p[b]) ? a : b);
            return <tr key={d}><td><b>{d}</b></td>{OR.map(o => <td key={o} style={{ fontWeight: o === dom ? 700 : 400 }}>{p[o]}</td>)}<td><Orient o={dom} /></td></tr>; })}
        </tbody></table>
      </Card>
      <div className="grid g2">
        <Card title="Transformation Probability Score" hint="0.35·D9 + 0.30·D8 + 0.20·leadership alignment + 0.15·D7">
          <div style={{ display: "flex", justifyContent: "center" }}><Gauge value={n(r.tps)} label={r.tps_band.replace(/_/g, " ")} provisional={r.provisional} coverage={n(r.coverage)} /></div><GaugeNote provisional={r.provisional} coverage={n(r.coverage)} />
          <table><tbody>
            <tr><td>D9 transformation readiness</td><td><b>{n(r.d9).toFixed(2)}</b></td><td>{r.d9_band}</td><td>α {r.alpha.D9}</td></tr>
            <tr><td>D8 candour</td><td><b>{n(r.d8).toFixed(2)}</b></td><td>{r.d8_band}</td><td>α {r.alpha.D8}</td></tr>
            <tr><td>Leadership alignment</td><td><b>{n(r.leadership_alignment).toFixed(2)}</b></td><td colSpan={2}>{r.leadership_alignment_source.replace(/_/g, " ").toLowerCase()}</td></tr>
            <tr><td>D7 change readiness</td><td><b>{n(r.d7).toFixed(2)}</b></td><td>{r.d7_band}</td><td>α {r.alpha.D7}</td></tr>
          </tbody></table>
        </Card>
        <Card title="Perception gap" hint={`Executive (n=${s.cohorts.executive.n}) versus staff (n=${s.cohorts.staff.n}), NOW`}>
          <PerceptionChart exec={s.cohorts.executive.now} staff={s.cohorts.staff.now} flags={s.perception_flags} />
        </Card>
      </div>
      <div className="grid g2">
        <Card title="Employee organisational sentiment (eOS)" hint="% likely (9–10) minus % unlikely (0–6) per item"><EosChart eos={s.eos} /></Card>
        <Card title="Data quality" hint={`Median completion time ${Math.round(s.quality.median_duration / 60)} minutes`}>
          <table><tbody>
            {Object.entries(s.quality.states).map(([k, v]: any) => <tr key={k}><td>{k.replace(/_/g, " ")}</td><td><b>{v}</b></td></tr>)}
            {Object.entries(s.quality.flags).map(([k, v]: any) => <tr key={k}><td>Flag · {k.replace(/_/g, " ").toLowerCase()}</td><td>{v}</td></tr>)}
          </tbody></table>
          <div className="label" style={{ marginTop: 16 }}>Lenses (NOW dominant)</div>
          <div className="pill-row" style={{ marginTop: 6 }}>{["STRATEGY", "PRACTICE", "LEADERSHIP"].map(l => <span key={l} className="badge b-neutral">{l}: {s.congruence.lens[l]}</span>)}<Verdict v={s.congruence.lens.agreement >= 3 ? "HIT" : "PARTIAL_HIT"} /></div>
        </Card>
      </div>
    </Page>
  );
}
