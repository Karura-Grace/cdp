import { Card, Page, useApi, Err, Loading } from "../components/ui";

export function Config() {
  const { data, error } = useApi<any>("/v1/config");
  if (error) return <Err e={error} />;
  if (!data) return <Loading />;
  return (
    <Page title="Configuration registry" sub={`Rules ${data.rules_version} · instrument ${data.instrument_version}. Changing a scoring key creates a new rules version; it never alters frozen results.`}>
      <Card><table><thead><tr><th>Key</th><th>Value</th></tr></thead><tbody>
        {Object.entries(data.keys).sort().map(([k, v]) => <tr key={k}><td><code>{k}</code></td><td><code>{JSON.stringify(v)}</code></td></tr>)}
      </tbody></table></Card>
    </Page>
  );
}

export function Audit() {
  const { data, error } = useApi<any[]>("/v1/audit");
  if (error) return <Page title="Audit log"><Err e={error} /></Page>;
  if (!data) return <Loading />;
  return (
    <Page title="Audit log" sub="Append-only record of setup edits, freezes, scoring, releases, plan changes and access to leader outputs (latest 200).">
      <Card><table><thead><tr><th>When</th><th>Actor</th><th>Action</th><th>Object</th></tr></thead><tbody>
        {data.map((a, i) => <tr key={i}><td>{a.at.slice(0, 19)}</td><td>{a.actor}</td><td>{a.action}</td><td>{a.object}</td></tr>)}
      </tbody></table></Card>
    </Page>
  );
}
