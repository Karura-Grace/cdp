import { useState } from "react";
import { api, A } from "../api";
import { Card, Page, useApi, Err, Loading } from "../components/ui";
import { useUser, isConsultant } from "../App";

export default function Fielding() {
  const u = useUser();
  const mon = useApi<any>(`/v1/assessments/${A}/monitor`);
  const [res, setRes] = useState<any>(null);
  const [err, setErr] = useState<any>(null);
  if (mon.error) return <Err e={mon.error} />;
  if (!mon.data) return <Loading />;
  const freeze = () => api(`/v1/assessments/${A}/freeze`, { method: "POST" }).then(r => { setRes(r); mon.reload(); }).catch(setErr);
  const rate = Math.round(mon.data.response_rate * 100);
  return (
    <Page title="Stage 2 · Assessment" sub="Survey fielding. Answers are separated from identity at submission; only aggregates are reported."
      actions={isConsultant(u) && <button className="btn orange" onClick={freeze}>Freeze response set</button>}>
      <Err e={err} />
      {res && <div className="ok">Frozen at {res.frozen_at} · {res.responses} responses · {res.response_set_hash.slice(0, 22)}…</div>}
      <div className="grid g3">
        <Card><div className="label">Invited</div><div className="kpi">{mon.data.invited}</div></Card>
        <Card><div className="label">Submitted</div><div className="kpi">{mon.data.submitted}</div></Card>
        <Card><div className="label">Response rate</div><div className="kpi">{rate}%</div>
          <div style={{ height: 8, background: "#EEF1F6", borderRadius: 4, marginTop: 8 }}><div style={{ width: rate + "%", height: 8, background: "#E8610A", borderRadius: 4 }} /></div></Card>
      </div>
      <Card title="Employee survey preview" hint="Each link is single-use. Open one in a new tab to complete the full instrument as an employee would.">
        <div className="pill-row">{[1, 2, 3, 4, 5].map(i => <a key={i} className="btn alt" href={`/survey/demo-token-${i}`} target="_blank" rel="noreferrer">demo-token-{i}</a>)}</div>
      </Card>
      <Card title="Instrument structure">
        <table><thead><tr><th>Part</th><th>Content</th><th>Format</th></tr></thead><tbody>
          <tr><td>D1–D6</td><td>18 scenarios, each answered NOW and PREFERRED</td><td>Allocate 100 points across four statements</td></tr>
          <tr><td>D7–D9</td><td>Change readiness, candour, transformation readiness (12 items each)</td><td>1–5 agreement scale</td></tr>
          <tr><td>eOS</td><td>8 organisational sentiment items</td><td>0–10 likelihood scale</td></tr>
          <tr><td>Qualitative</td><td>3 open questions</td><td>Free text, screened for identifying details</td></tr>
        </tbody></table>
      </Card>
    </Page>
  );
}
