export type User = { id: string; name: string; role: string; email: string; is_people_lead?: boolean };
let token = localStorage.getItem("cdp_token") || "";
export const setToken = (t: string) => { token = t; try { localStorage.setItem("cdp_token", t); } catch {} };
export class ApiError extends Error { code: string; body: any; status: number;
  constructor(status: number, body: any) { super(body?.title || "Request failed"); this.code = body?.code; this.body = body; this.status = status; } }
export async function api<T = any>(path: string, opts: { method?: string; body?: any; params?: Record<string, string> } = {}): Promise<T> {
  const qs = opts.params ? "?" + new URLSearchParams(opts.params).toString() : "";
  const r = await fetch(path + qs, { method: opts.method || "GET", headers: { "Content-Type": "application/json", ...(token ? { Authorization: "Bearer " + token } : {}) },
    body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new ApiError(r.status, j);
  return j as T;
}
export const A = "asm_demo";
export const E = "eng_demo";
export const OR = ["ENGAGE", "INNOVATE", "PERFORM", "GOVERN"] as const;
export const OC: Record<string, string> = { ENGAGE: "#2E86C1", INNOVATE: "#6C3483", PERFORM: "#C0392B", GOVERN: "#4E9A52" };
export const n = (x: any) => (x === null || x === undefined ? NaN : Number(x));
export const pretty = (s?: string) => (s || "").replace(/_/g, " ").toLowerCase().replace(/^\w/, c => c.toUpperCase());
