import { createContext, useContext, useEffect, useState } from "react";
import { NavLink, Navigate, Route, Routes, useLocation } from "react-router-dom";
import { api, setToken, User } from "./api";
import Login from "./pages/Login";
import Overview from "./pages/Overview";
import Setup from "./pages/Setup";
import Survey from "./pages/Survey";
import Fielding from "./pages/Fielding";
import Scoring from "./pages/Scoring";
import Segments from "./pages/Segments";
import Findings from "./pages/Findings";
import Reports from "./pages/Reports";
import Leaders from "./pages/Leaders";
import Plan from "./pages/Plan";
import Dashboard from "./pages/Dashboard";
import Reassess from "./pages/Reassess";
import { Config, Audit } from "./pages/Admin";

export const UserCtx = createContext<User | null>(null);
export const useUser = () => useContext(UserCtx)!;
export const isConsultant = (u: User) => u.role === "PAC_CONSULTANT";

const NAV: { grp: string; items: [string, string, string?][] }[] = [
  { grp: "ENGAGEMENT", items: [["/", "Overview"]] },
  { grp: "STAGES", items: [["/setup", "Setup", "1"], ["/fielding", "Assessment", "2"], ["/scoring", "Scoring", "3"], ["/segments", "Segments", "3"],
    ["/findings", "Findings", "4"], ["/reports", "Reports", "4"], ["/leaders", "Leader 360", "4"], ["/plan", "Action plan", "5"], ["/dashboard", "Executive dashboard", "5"], ["/reassess", "Re-assessment", "6"]] },
  { grp: "GOVERNANCE", items: [["/config", "Configuration"], ["/audit", "Audit log"]] },
];

export default function App() {
  const loc = useLocation();
  const [user, setUser] = useState<User | null>(null);
  const [checked, setChecked] = useState(false);
  useEffect(() => { api<User>("/v1/me").then(setUser).catch(() => setUser(null)).finally(() => setChecked(true)); }, []);

  if (loc.pathname.startsWith("/survey")) return <Routes><Route path="/survey/:token" element={<Survey />} /></Routes>;
  if (!checked) return null;
  if (!user) return <Login onLogin={u => setUser(u)} />;

  const logout = () => { setToken(""); setUser(null); };
  return (
    <UserCtx.Provider value={user}>
      <div className="shell">
        <aside className="side">
          <div className="brand">PRIORITY ACTIVATOR CONSULTING<b>Culture Dynamics Profile</b></div>
          <nav className="nav">
            {NAV.map(g => <div key={g.grp}><div className="grp">{g.grp}</div>
              {g.items.map(([to, label, num]) => <NavLink key={to} to={to} end={to === "/"}>{num ? <span className="num">{num}</span> : <span className="num">•</span>}{label}</NavLink>)}</div>)}
          </nav>
          <div style={{ marginTop: 24, fontSize: 12.5, color: "#c9d3e6" }}>
            <div><b style={{ color: "#fff" }}>{user.name}</b></div><div>{user.role.replace(/_/g, " ")}</div>
            <button className="btn alt" style={{ marginTop: 10, padding: "6px 10px" }} onClick={logout}>Sign out</button>
          </div>
        </aside>
        <main className="main">
          <Routes>
            <Route path="/" element={<Overview />} />
            <Route path="/setup" element={<Setup />} />
            <Route path="/fielding" element={<Fielding />} />
            <Route path="/scoring" element={<Scoring />} />
            <Route path="/segments" element={<Segments />} />
            <Route path="/findings" element={<Findings />} />
            <Route path="/reports" element={<Reports />} />
            <Route path="/leaders" element={<Leaders />} />
            <Route path="/plan" element={<Plan />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/reassess" element={<Reassess />} />
            <Route path="/config" element={<Config />} />
            <Route path="/audit" element={<Audit />} />
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </main>
      </div>
    </UserCtx.Provider>
  );
}
