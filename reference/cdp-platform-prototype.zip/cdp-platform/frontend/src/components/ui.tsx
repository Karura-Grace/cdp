import { ReactNode, useEffect, useState, useCallback } from "react";
import { api, ApiError, OC, pretty } from "../api";

export function useApi<T = any>(path: string | null, params?: Record<string, string>) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<ApiError | null>(null);
  const key = path + JSON.stringify(params || {});
  const load = useCallback(() => {
    if (!path) return;
    setError(null);
    api<T>(path, { params }).then(setData).catch(setError);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);
  useEffect(load, [load]);
  return { data, error, reload: load };
}

export const Card = ({ title, hint, children, right }: { title?: string; hint?: string; children: ReactNode; right?: ReactNode }) => (
  <div className="card">
    {(title || right) && <div style={{ display: "flex", justifyContent: "space-between", gap: 12 }}><div>{title && <h3>{title}</h3>}{hint && <div className="hint">{hint}</div>}</div>{right}</div>}
    {children}
  </div>
);

export function Verdict({ v }: { v?: string | null }) {
  if (!v) return null;
  const cls = v.includes("MISS") || v === "SHADOW_CULTURE" || v === "CRITICAL" || v === "RED" ? "b-miss" : v.includes("PARTIAL") || v === "WATCH" || v === "HIGH" || v === "AMBER" ? "b-partial" : v === "HIT" || v === "GREEN" ? "b-hit" : "b-neutral";
  const icon = cls === "b-miss" ? "✕" : cls === "b-partial" ? "◐" : cls === "b-hit" ? "✓" : "•";
  return <span className={"badge " + cls}>{icon} {v.replace(/_/g, " ")}</span>;
}

export const Orient = ({ o }: { o: string }) => <span><span className="o-dot" style={{ background: OC[o] }} />{o}</span>;

export const Page = ({ title, sub, children, actions }: { title: string; sub?: string; children: ReactNode; actions?: ReactNode }) => (
  <div>
    <div className="top"><div><h1>{title}</h1>{sub && <div className="sub">{sub}</div>}</div>{actions}</div>
    <div className="grid">{children}</div>
  </div>
);

export const Err = ({ e }: { e: ApiError | null }) => e ? <div className="err"><b>{e.code || "Error"}</b> · {e.message}{e.body?.missing ? " (" + e.body.missing.join(", ") + ")" : ""}{e.body?.issues ? <ul>{e.body.issues.map((i: string) => <li key={i}>{i}</li>)}</ul> : null}</div> : null;
export const Loading = () => <div className="card" style={{ color: "#5A6478" }}>Loading…</div>;
export { pretty };
