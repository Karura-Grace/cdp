import { Bar, BarChart, CartesianGrid, Cell, LabelList, Legend, ReferenceArea, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { OC, OR, n } from "../api";

const tint = (hex: string) => hex + "59";

export function ProfileChart({ now, pref }: { now: any; pref: any }) {
  const data = OR.map(o => ({ o, NOW: n(now[o]), PREFERRED: n(pref[o]) }));
  return (
    <ResponsiveContainer width="100%" height={280}>
      <BarChart data={data} barGap={4} margin={{ top: 20, right: 10, left: -10, bottom: 0 }}>
        <CartesianGrid vertical={false} stroke="#E6E9EF" />
        <XAxis dataKey="o" tick={{ fontSize: 12, fontWeight: 600 }} /><YAxis domain={[0, 40]} tick={{ fontSize: 11 }} />
        <Tooltip formatter={(v: any) => Number(v).toFixed(1)} />
        <ReferenceLine y={25} stroke="#E8610A" strokeDasharray="4 3" label={{ value: "neutral 25", position: "right", fontSize: 10, fill: "#E8610A" }} />
        <Bar dataKey="NOW" radius={[4, 4, 0, 0]}>{data.map(d => <Cell key={d.o} fill={tint(OC[d.o])} stroke={OC[d.o]} />)}<LabelList dataKey="NOW" position="top" fontSize={11} formatter={(v: any) => Math.round(v)} /></Bar>
        <Bar dataKey="PREFERRED" radius={[4, 4, 0, 0]}>{data.map(d => <Cell key={d.o} fill={OC[d.o]} />)}<LabelList dataKey="PREFERRED" position="top" fontSize={11} fontWeight={700} formatter={(v: any) => Math.round(v)} /></Bar>
        <Legend formatter={(v) => v === "NOW" ? "NOW (light)" : "PREFERRED (solid)"} wrapperStyle={{ fontSize: 12 }} />
      </BarChart>
    </ResponsiveContainer>
  );
}

export function GapChart({ gap, cls }: { gap: any; cls: any }) {
  const data = OR.map(o => ({ o, gap: n(gap[o]), cls: cls[o] }));
  return (<div>
    <ResponsiveContainer width="100%" height={240}>
      <BarChart data={data} layout="vertical" margin={{ left: 10, right: 20 }}>
        <ReferenceArea x1={-18} x2={-8} fill="#F3E1DE" /><ReferenceArea x1={-8} x2={-4} fill="#F8EEEC" />
        <ReferenceArea x1={-4} x2={4} fill="#F2F3F5" /><ReferenceArea x1={4} x2={8} fill="#E8F0F7" /><ReferenceArea x1={8} x2={18} fill="#D9E7F3" />
        <XAxis type="number" domain={[-18, 18]} ticks={[-16, -8, -4, 0, 4, 8, 16]} tick={{ fontSize: 11 }} />
        <YAxis type="category" dataKey="o" tick={{ fontSize: 12, fontWeight: 600 }} width={80} />
        <ReferenceLine x={0} stroke="#5A6478" /><Tooltip />
        <Bar dataKey="gap" barSize={22} radius={4}>{data.map(d => <Cell key={d.o} fill={OC[d.o]} />)}
          <LabelList dataKey="gap" position="insideRight" fill="#fff" fontSize={11} fontWeight={700} formatter={(v: any) => (v > 0 ? "+" : "") + v} />
        </Bar>
      </BarChart>
    </ResponsiveContainer>
    <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 6, marginTop: 6 }}>{data.map(d => <div key={d.o} style={{ fontSize: 12, borderLeft: `4px solid ${OC[d.o]}`, paddingLeft: 8 }}>
      <b>{d.o}</b><br />{d.gap > 0 ? "+" : ""}{d.gap.toFixed(1)} · {String(d.cls).replace(/_/g, " ")}</div>)}</div>
    </div>
  );
}

export function Gauge({ value, label, provisional, coverage }: { value: number; label: string; provisional?: boolean; coverage?: number }) {
  const bands = [[1, 2.5, "#C0392B"], [2.5, 3.5, "#E59A2F"], [3.5, 4, "#9CC79F"], [4, 5, "#3E8E52"]] as const;
  const ang = (v: number) => Math.PI - ((v - 1) / 4) * Math.PI;
  const pt = (v: number, r: number) => [120 + r * Math.cos(ang(v)), 120 - r * Math.sin(ang(v))];
  const arc = (a: number, b: number) => { const [x1, y1] = pt(a, 100), [x2, y2] = pt(b, 100), [x3, y3] = pt(b, 70), [x4, y4] = pt(a, 70);
    return `M${x1},${y1} A100,100 0 0 1 ${x2},${y2} L${x3},${y3} A70,70 0 0 0 ${x4},${y4} Z`; };
  const [nx, ny] = pt(value, 88);
  return (
    <svg viewBox="0 0 240 172" style={{ width: "100%", maxWidth: 340 }} role="img" aria-label={`TPS ${value}`}>
      {bands.map(([a, b, c]) => <path key={a} d={arc(a, b)} fill={c} stroke="#fff" strokeWidth={2} />)}
      <line x1={120} y1={120} x2={nx} y2={ny} stroke="#1C2B4A" strokeWidth={4} strokeLinecap="round" /><circle cx={120} cy={120} r={7} fill="#1C2B4A" />
      <text x={120} y={150} textAnchor="middle" fontSize={24} fontWeight={700} fill="#1C2B4A">{value.toFixed(2)}</text>
      <text x={120} y={166} textAnchor="middle" fontSize={10} fill="#5A6478">{label}</text>
      {[1, 2, 3, 4, 5].map(v => { const [x, y] = pt(v, 58); return <text key={v} x={x} y={y + 3} fontSize={9} textAnchor="middle" fill="#5A6478">{v}</text>; })}
    </svg>
  );
}
export const GaugeNote = ({ provisional, coverage }: { provisional?: boolean; coverage?: number }) =>
  provisional ? <div style={{ textAlign: "center", fontSize: 12, color: "#9A3C00", marginBottom: 8 }}>PROVISIONAL · leader 360 coverage {Math.round((coverage || 0) * 100)}%</div> : null;

export function PerceptionChart({ exec, staff, flags }: { exec: any; staff: any; flags: any }) {
  return (
    <div>
      {OR.map(o => {
        const e = n(exec[o]), s = n(staff[o]), lo = Math.min(e, s), hi = Math.max(e, s), sc = (v: number) => ((v - 5) / 40) * 100;
        return (
          <div key={o} style={{ display: "grid", gridTemplateColumns: "90px 1fr 140px", alignItems: "center", gap: 10, padding: "10px 0", borderBottom: "1px solid #E2E6EE" }}>
            <b style={{ fontSize: 12.5 }}>{o}</b>
            <div style={{ position: "relative", height: 22 }}>
              <div style={{ position: "absolute", left: sc(lo) + "%", width: sc(hi) - sc(lo) + "%", top: 9, height: 4, background: OC[o], opacity: .6, borderRadius: 2 }} />
              <div title={"Executive " + e} style={{ position: "absolute", left: `calc(${sc(e)}% - 7px)`, top: 4, width: 14, height: 14, borderRadius: 7, background: OC[o] }} />
              <div title={"Staff " + s} style={{ position: "absolute", left: `calc(${sc(s)}% - 7px)`, top: 4, width: 13, height: 13, transform: "rotate(45deg)", border: `2.5px solid ${OC[o]}`, background: "#fff" }} />
            </div>
            <span style={{ fontSize: 12.5 }}><b>{Math.abs(e - s).toFixed(1)}</b> {flags[o] !== "NONE" && <span className={"badge " + (flags[o] === "SHADOW_CULTURE" ? "b-miss" : "b-partial")}>{flags[o].replace("_", " ")}</span>}</span>
          </div>);
      })}
      <div style={{ fontSize: 12, color: "#5A6478", marginTop: 8 }}>● executive · ◇ staff · scale 5–45 · WATCH &gt; 5.0 · SHADOW CULTURE &gt; 7.0</div>
    </div>
  );
}

const EOS_NAMES = ["Recommend as a great place to work", "Quality of leadership", "Commitment to innovation", "Development and career growth", "Transparency of communication", "Work-life integration and wellbeing", "Inclusion, fairness and equity", "Strategy into daily purpose"];
export function EosChart({ eos }: { eos: any }) {
  const data = EOS_NAMES.map((name, i) => ({ name: `Q${i + 1} ${name}`, v: n(eos["Q" + (i + 1)]) }));
  return (
    <ResponsiveContainer width="100%" height={300}>
      <BarChart data={data} layout="vertical" margin={{ left: 160, right: 30 }}>
        <ReferenceArea x1={-40} x2={0} fill="#FBF0EE" /><ReferenceArea x1={30} x2={60} fill="#EEF5EF" />
        <XAxis type="number" domain={[-30, 50]} tick={{ fontSize: 11 }} /><YAxis type="category" dataKey="name" tick={{ fontSize: 11 }} width={150} />
        <ReferenceLine x={0} stroke="#5A6478" /><ReferenceLine x={n(eos.index)} stroke="#1C2B4A" strokeDasharray="3 2" label={{ value: "Index " + eos.index, fontSize: 10, position: "top" }} />
        <Tooltip /><Bar dataKey="v" barSize={16} radius={3}>{data.map(d => <Cell key={d.name} fill={d.v < 0 ? "#B03A2E" : "#2E6DA4"} />)}<LabelList dataKey="v" position="right" fontSize={11} /></Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

export function Leader360Chart({ self, other, gaps }: { self: any; other: any; gaps: any }) {
  const names: Record<string, string> = { A: "A ENGAGE", B: "B INNOVATE", C: "C PERFORM", D: "D GOVERN", E: "E Integrity", F: "F Psych. safety", G: "G Strategy & digital", H: "H Leading change" };
  const col = (s: string) => ({ A: OC.ENGAGE, B: OC.INNOVATE, C: OC.PERFORM, D: OC.GOVERN } as any)[s] || "#5A6478";
  const sc = (v: number) => ((v - 2) / 3) * 100;
  return (
    <div>
      {Object.keys(names).map(s => { const a = n(self[s]), b = n(other[s]); const t = gaps[s]?.tier;
        return (
          <div key={s} style={{ display: "grid", gridTemplateColumns: "150px 1fr 120px", gap: 10, alignItems: "center", padding: "7px 0", borderBottom: "1px solid #E2E6EE" }}>
            <span style={{ fontSize: 12.5 }}>{names[s]}</span>
            <div style={{ position: "relative", height: 20 }}>
              <div style={{ position: "absolute", left: sc(3) + "%", top: 0, bottom: 0, borderLeft: "1px dashed #A93226" }} />
              <div style={{ position: "absolute", left: sc(Math.min(a, b)) + "%", width: Math.abs(sc(a) - sc(b)) + "%", top: 8, height: 4, background: col(s), opacity: .5 }} />
              <div title={"Others " + b.toFixed(2)} style={{ position: "absolute", left: `calc(${sc(b)}% - 7px)`, top: 3, width: 14, height: 14, borderRadius: 7, background: col(s) }} />
              <div title={"Self " + a.toFixed(2)} style={{ position: "absolute", left: `calc(${sc(a)}% - 6px)`, top: 4, width: 12, height: 12, transform: "rotate(45deg)", border: `2.5px solid ${col(s)}`, background: "#fff" }} />
            </div>
            <span style={{ fontSize: 12 }}><b>{(a - b >= 0 ? "+" : "") + (a - b).toFixed(1)}</b> {t && t !== "ALIGNED" && <span className={"badge " + (t === "BLIND_SPOT" ? "b-miss" : "b-partial")}>{t.replace("_", " ")}</span>}</span>
          </div>);
      })}
      <div style={{ fontSize: 12, color: "#5A6478", marginTop: 8 }}>● others · ◇ self · scale 2–5 · dashed line = 3.00 flag</div>
    </div>
  );
}
