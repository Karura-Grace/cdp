@echo off
REM CDP Platform - one-click local start (Windows). Needs Python 3.11+ and Node.js 20+ installed.
cd /d "%~dp0"
if not exist backend\.venv (
  echo Creating Python environment...
  python -m venv backend\.venv || goto :err
)
call backend\.venv\Scripts\activate.bat
pip install -q -r backend\requirements.txt || goto :err
if not exist frontend\dist\index.html (
  echo Building the web interface...
  pushd frontend
  call npm install || goto :err
  call npm run build || goto :err
  popd
)
cd backend
python -m app.seed --if-empty
echo.
echo  CDP Platform running at http://localhost:8000   (Ctrl+C to stop)
echo.
start "" http://localhost:8000
python -m uvicorn app.main:app --port 8000
goto :eof
:err
echo Setup failed - see the messages above.
pause
