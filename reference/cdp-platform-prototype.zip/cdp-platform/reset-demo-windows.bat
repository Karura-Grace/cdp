@echo off
REM Rebuilds the demonstration database (Mwangaza Bank) from scratch.
cd /d "%~dp0backend"
call .venv\Scripts\activate.bat
python -m app.seed
pause
