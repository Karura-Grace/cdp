"""CDP Platform API (spec Appendix B). Run: uvicorn app.main:app --reload"""
import json
import os
from datetime import date, datetime, timezone
from fastapi import FastAPI, Depends, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, HTMLResponse
from pydantic import BaseModel
from sqlalchemy import select, func

from .db import (init_db, Tenant, User, Engagement, SetupRecord, Assessment, Invitation, Consent, Response, Leader360,
                 ScoreObject, Plan, Action, ActionEvent, Evidence, KpiReading, Report, AuditLog, SegmentQueryLog, nid, now, OrgUnit)
from .security import db, current_user, require, sign, CONSULTANT, CLIENT_READ
from .services import run_score, compute_all, run_plan, audit, engine_setup, setup_records
from .engine import scoring as S, checks as C, planning as P, reassess as R, suppression as X, config as cfg
from .engine.num import to_jsonable, D, q, ORIENTATIONS, DIMENSIONS_CS
from . import ai

from contextlib import asynccontextmanager


@asynccontextmanager
async def lifespan(app):
    init_db()
    yield

app = FastAPI(title="CDP Platform API", version="2.1", description="Culture Dynamics Profile platform — PAC/CDP/TECH/001 v2.1", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
ITEMS = json.load(open(os.path.join(os.path.dirname(__file__), "data", "item_bank.json"), encoding="utf-8"))


def problem(status, code, title, **extra):
    raise HTTPException(status, {"code": code, "title": title, **extra})


@app.exception_handler(HTTPException)
async def http_exc(request: Request, exc: HTTPException):
    body = exc.detail if isinstance(exc.detail, dict) else {"code": "ERROR", "title": str(exc.detail)}
    return JSONResponse({"type": f"https://cdp.pac.africa/problems/{body.get('code','error').lower()}", "status": exc.status_code, **body}, status_code=exc.status_code)


@app.exception_handler(P.WorkflowError)
async def wf_exc(request: Request, exc: P.WorkflowError):
    return JSONResponse({"status": exc.status, "code": exc.code, "title": exc.detail}, status_code=exc.status)


def get_assessment(s, a_id) -> Assessment:
    a = s.get(Assessment, a_id)
    if not a:
        problem(404, "NOT_FOUND", "Assessment not found")
    return a


def latest_score(s, a_id):
    so = s.scalars(select(ScoreObject).where(ScoreObject.assessment_id == a_id).order_by(ScoreObject.version.desc())).first()
    if not so:
        problem(409, "NOT_SCORED", "Run scoring first")
    return so

# ------------------------------------------------------------------ auth


class Login(BaseModel):
    email: str


@app.post("/v1/auth/login")
def login(body: Login, s=Depends(db)):
    u = s.scalars(select(User).where(User.email == body.email)).first()
    if not u:
        problem(401, "UNAUTHENTICATED", "Unknown user")
    return {"token": sign(u.id), "user": {"id": u.id, "name": u.name, "role": u.role, "email": u.email, "is_people_lead": u.is_people_lead}}


@app.get("/v1/auth/demo-users")
def demo_users(s=Depends(db)):
    return [{"email": u.email, "name": u.name, "role": u.role} for u in s.scalars(select(User).order_by(User.role))]


@app.get("/v1/me")
def me(u=Depends(current_user)):
    return {"id": u.id, "name": u.name, "role": u.role, "email": u.email, "is_people_lead": u.is_people_lead}

# ------------------------------------------------------------------ engagements and setup (Stage 1)


@app.get("/v1/engagements")
def engagements(u=Depends(current_user), s=Depends(db)):
    out = []
    for e in s.scalars(select(Engagement)):
        t = s.get(Tenant, e.tenant_id)
        a = s.scalars(select(Assessment).where(Assessment.engagement_id == e.id)).first()
        out.append({"id": e.id, "state": e.state, "cycle_no": e.cycle_no, "tenant": {"id": t.id, "name": t.name, "sector": t.sector,
                    "headcount": t.headcount, "privacy_regime": t.privacy_regime, "residency_region": t.residency_region},
                    "assessment": {"id": a.id, "status": a.status, "window_open": a.window_open, "window_close": a.window_close} if a else None})
    return out


@app.get("/v1/engagements/{e_id}/setup")
def setup_all(e_id: str, u=Depends(require(*CLIENT_READ)), s=Depends(db)):
    rows = s.scalars(select(SetupRecord).where(SetupRecord.engagement_id == e_id))
    return [{"section": r.section, "perspective": r.perspective, "status": r.status, "workshop_date": r.workshop_date,
             "participants": r.participants, "payload": r.payload} for r in rows]


class SetupPut(BaseModel):
    payload: dict
    perspective: str = "AGREED"


@app.put("/v1/engagements/{e_id}/setup/{section}")
def setup_put(e_id: str, section: str, body: SetupPut, u=Depends(require("PAC_CONSULTANT", "CLIENT_ADMIN")), s=Depends(db)):
    e = s.get(Engagement, e_id)
    if e.state != "SETUP":
        problem(409, "SETUP_LOCKED", "Setup is locked after launch; create a new assessment version to change scoring inputs")
    r = s.scalars(select(SetupRecord).where(SetupRecord.engagement_id == e_id, SetupRecord.section == section, SetupRecord.perspective == body.perspective)).first()
    if not r:
        r = SetupRecord(id=nid("set"), engagement_id=e_id, section=section, perspective=body.perspective)
        s.add(r)
    r.payload = body.payload
    r.status = "DRAFT"
    audit(s, u.id, "SETUP_EDIT", f"{e_id}/{section}")
    s.commit()
    return {"ok": True}


class Agree(BaseModel):
    workshop_date: str
    participants: list[str]


@app.post("/v1/engagements/{e_id}/setup/{section}/agree")
def setup_agree(e_id: str, section: str, body: Agree, u=Depends(require(*CONSULTANT)), s=Depends(db)):
    if len(body.participants) < 2:
        problem(422, "WORKSHOP_RECORD_MISSING", "At least two named executive participants are required")
    r = s.scalars(select(SetupRecord).where(SetupRecord.engagement_id == e_id, SetupRecord.section == section, SetupRecord.perspective == "AGREED")).first()
    r.status, r.workshop_date, r.participants = "AGREED", body.workshop_date, body.participants
    s.commit()
    return {"ok": True}


@app.get("/v1/engagements/{e_id}/requirements")
def requirements(e_id: str, u=Depends(require(*CLIENT_READ)), s=Depends(db)):
    return to_jsonable(engine_setup(s, e_id))


@app.post("/v1/assessments/{a_id}/preflight")
def preflight(a_id: str, u=Depends(require(*CONSULTANT)), s=Depends(db)):
    a = get_assessment(s, a_id)
    rec = setup_records(s, a.engagement_id)
    checks = []
    agreed = all(sec in rec and rec[sec].status == "AGREED" and len(rec[sec].participants) >= 2 for sec in "BCDEFGHI")
    checks.append({"id": "L2", "check": "Sections B–I agreed with workshop records", "pass": agreed, "blocking": True})
    try:
        setup = engine_setup(s, a.engagement_id); ok3 = bool(setup["c1_requirements"])
    except Exception:
        ok3 = False
    checks.append({"id": "L3", "check": "Priorities tagged, business model set, leadership target resolved", "pass": ok3, "blocking": True})
    kp = rec.get("C") and rec["C"].payload.get("kpis")
    checks.append({"id": "L4", "check": "Scorecard has a KPI with baseline and 12-month target", "pass": bool(kp), "blocking": True})
    wd = sum(1 for i in range((date.fromisoformat(a.window_close) - date.fromisoformat(a.window_open)).days + 1)
             if date.fromordinal(date.fromisoformat(a.window_open).toordinal() + i).weekday() < 5)
    checks.append({"id": "L5", "check": f"Window ≥ {cfg.get('survey.min_window_working_days')} working days ({wd})", "pass": wd >= cfg.get("survey.min_window_working_days"), "blocking": True})
    t = s.get(Tenant, s.get(Engagement, a.engagement_id).tenant_id)
    checks.append({"id": "L6", "check": "Privacy regime, residency and consent text set", "pass": bool(t.privacy_regime and t.residency_region), "blocking": True})
    return {"pass": all(c["pass"] for c in checks if c["blocking"]), "checks": checks}

# ------------------------------------------------------------------ survey (Stage 2)


def instrument():
    now = [x for x in ITEMS["scen"] if x["persp"] == "NOW"]
    pref = [x for x in ITEMS["scen"] if x["persp"] == "PREFERRED"]
    return {"scenarios": [{"scenario_id": f"{n['dim']}-S{n['s']}", "dimension": n["dim"], "title": n["title"], "prompt_now": n["prompt"],
                           "prompt_preferred": p["prompt"].replace("PREFERRED perspective: ", ""),
                           "statements": [{"orientation": o, "text": n["statements"][o]} for o in ORIENTATIONS]} for n, p in zip(now, pref)],
            "likert": {d: [{"item_id": f"{d}-{i+1:02d}", "text": t} for i, t in enumerate(v)] for d, v in ITEMS["likert"].items()},
            "eos": [{"item_id": f"EOS-Q{i+1}", "text": t} for i, t in enumerate(ITEMS["eos"])],
            "qualitative": [{"item_id": f"QUAL-{x['code']}", "title": x["title"], "text": x["text"]} for x in ITEMS["qual"]]}


@app.get("/v1/survey")
def survey(token: str, s=Depends(db)):
    inv = s.scalars(select(Invitation).where(Invitation.token == token)).first()
    if not inv or inv.submitted_at:
        problem(410, "TOKEN_INVALID", "This survey link has expired or has already been used")
    a = s.get(Assessment, inv.assessment_id)
    t = s.get(Tenant, s.get(Engagement, a.engagement_id).tenant_id)
    return {"organisation": t.name, "assessment_id": a.id, "window_close": a.window_close, "completion_estimate": "35–45 minutes",
            "consent_text_version": "cst_KE_v4", "instrument": instrument(), "draft": inv.draft,
            "consent_text": (f"{t.legal_name} has asked Priority Activator Consulting to run the Culture Dynamics Profile. Your answers are used only "
                             "to understand the organisation’s culture and are reported in groups of at least five people. When you submit, your answers "
                             "are separated from your name and can no longer be retrieved or deleted individually. Data is kept for 24 months. "
                             "Taking part is voluntary and you can stop at any time before submitting.")}


class SurveySubmit(BaseModel):
    consent: bool
    language: str = "en-GB"
    duration_seconds: int | None = None
    alloc: dict = {}
    likert: dict = {}
    eos: list = []
    qualitative: dict = {}
    submit: bool = False


@app.put("/v1/survey/response")
def survey_submit(token: str, body: SurveySubmit, s=Depends(db)):
    inv = s.scalars(select(Invitation).where(Invitation.token == token)).first()
    if not inv or inv.submitted_at:
        problem(409 if inv else 410, "ALREADY_SUBMITTED" if inv else "TOKEN_INVALID", "This survey has already been submitted")
    if not body.consent:
        s.add(Consent(id=nid("cns"), invitation_id=inv.id, text_version="cst_KE_v4", decision="DECLINE"))
        s.commit()
        return {"status": "DECLINED"}
    for persp, dims in body.alloc.items():
        for d, scen in dims.items():
            for i, sc in enumerate(scen):
                if sc is None:
                    continue
                vals = [sc.get(o) for o in ORIENTATIONS]
                if any(not isinstance(v, int) or v < 0 or v > 100 for v in vals) or sum(vals) != 100:
                    problem(422, "CONSTANT_SUM_VIOLATION", "Allocations must be whole numbers totalling exactly 100",
                            scenario_id=f"{d}-S{i+1}", perspective=persp, received=sum(v for v in vals if isinstance(v, int)))
    for d, vals in body.likert.items():
        if any(v is not None and (not isinstance(v, int) or not 1 <= v <= 5) for v in vals):
            problem(422, "SCALE_OUT_OF_RANGE", f"{d} items accept 1–5")
    if any(v is not None and (not isinstance(v, int) or not 0 <= v <= 10) for v in body.eos):
        problem(422, "SCALE_OUT_OF_RANGE", "eOS items accept 0–10")
    if not body.submit:
        inv.draft = body.model_dump()
        s.commit()
        return {"status": "DRAFT_SAVED"}
    s.add(Consent(id=nid("cns"), invitation_id=None, text_version="cst_KE_v4", decision="AGREE"))
    s.add(Response(id=nid("rsp"), assessment_id=inv.assessment_id, snapshot=inv.snapshot, language=body.language, duration=body.duration_seconds,
                   payload={"alloc": body.alloc, "likert": body.likert, "eos": body.eos}, text=body.qualitative))
    inv.submitted_at = now(); inv.person_id = None; inv.link_destroyed_at = now(); inv.draft = None   # identity unlinked
    s.commit()
    return {"status": "SUBMITTED"}


@app.get("/v1/assessments/{a_id}/monitor")
def monitor(a_id: str, u=Depends(require("PAC_CONSULTANT", "CLIENT_ADMIN")), s=Depends(db)):
    invited = s.scalar(select(func.count()).select_from(Invitation).where(Invitation.assessment_id == a_id))
    submitted = s.scalar(select(func.count()).select_from(Response).where(Response.assessment_id == a_id))
    return {"invited": invited, "submitted": submitted, "response_rate": round(submitted / invited, 3) if invited else 0}


@app.post("/v1/assessments/{a_id}/freeze")
def freeze(a_id: str, u=Depends(require(*CONSULTANT)), s=Depends(db)):
    a = get_assessment(s, a_id)
    import hashlib
    ids = [r for r in s.scalars(select(Response.id).where(Response.assessment_id == a_id).order_by(Response.id))]
    a.response_set_hash = "sha256:" + hashlib.sha256("|".join(ids).encode()).hexdigest()
    a.status, a.frozen_at = "FROZEN", now()
    e = s.get(Engagement, a.engagement_id)
    if e.state in ("SETUP", "FIELDING"):
        e.state = "SCORING"
    audit(s, u.id, "FREEZE", a_id, hash=a.response_set_hash)
    s.commit()
    return {"frozen_at": str(a.frozen_at), "response_set_hash": a.response_set_hash, "responses": len(ids)}

# ------------------------------------------------------------------ scoring (Stage 3)


@app.post("/v1/assessments/{a_id}/score")
def score(a_id: str, u=Depends(require(*CONSULTANT)), s=Depends(db)):
    a = get_assessment(s, a_id)
    if a.status not in ("FROZEN", "SCORED"):
        problem(409, "DATA_NOT_FROZEN", "Freeze the dataset before scoring")
    obj, so = run_score(s, a, u.id)
    return {"score_version": so.version, "payload_hash": so.payload_hash, "score": so.payload}


@app.get("/v1/assessments/{a_id}/score")
def get_score(a_id: str, u=Depends(require(*CLIENT_READ)), s=Depends(db)):
    so = latest_score(s, a_id)
    return {"score_version": so.version, "payload_hash": so.payload_hash, "frozen": so.frozen, "score": so.payload}


@app.post("/v1/assessments/{a_id}/score/freeze")
def score_freeze(a_id: str, u=Depends(require(*CONSULTANT)), s=Depends(db)):
    so = latest_score(s, a_id); so.frozen = True
    e = s.get(Engagement, get_assessment(s, a_id).engagement_id)
    if e.state == "SCORING":
        e.state = "REPORTING"
    s.commit()
    return {"frozen": True, "payload_hash": so.payload_hash}


SEGMENT_AXES = ("department", "grade", "tenure_band")


@app.get("/v1/assessments/{a_id}/segments")
def segments(a_id: str, axis: str = "department", u=Depends(require(*CLIENT_READ)), s=Depends(db)):
    if axis not in SEGMENT_AXES:
        problem(422, "VALIDATION_FAILED", f"axis must be one of {SEGMENT_AXES}")
    _, obj, *_ = compute_all(s, get_assessment(s, a_id))
    resp = [r for r in _responses_scored(s, a_id) if S.included(r, "NOW")]
    org = obj["orientation_scores"]["now"]
    names = {x.id: x.name for x in s.scalars(select(OrgUnit))}
    groups = {}
    for r in resp:
        groups.setdefault(r["snapshot"].get(axis, "UNKNOWN"), []).append(r)
    out = []
    for k, rs in sorted(groups.items()):
        n = len(rs)
        s.add(SegmentQueryLog(id=nid("qry"), actor=u.id, predicates={axis: k}, resolved_count=n, outcome="OK" if n >= cfg.get("segments.floor") else "SUPPRESSED"))
        if n < cfg.get("segments.floor"):
            out.append({"segment": k, "label": names.get(k, k), "n": None, "suppressed": True, "reason": "below reporting threshold"})
            continue
        prof = S.orientation_profile(rs, "NOW")
        rest = [r for r in resp if r["snapshot"].get(axis) != k]
        sub = S.subculture(rs, rest, prof, org)
        cats, idx = S.eos_scores([r for r in rs if r.get("eos")])
        out.append({"segment": k, "label": names.get(k, k), "n": n, "suppressed": False, "now": prof,
                    "diff": {o: q(prof[o] - org[o], 2) for o in ORIENTATIONS}, "subculture": sub, "eos_index": idx,
                    "eos_negative": [c for c, v in cats.items() if v is not None and v < 0]})
    s.commit()
    return to_jsonable({"axis": axis, "organisation": org, "segments": out})


def _responses_scored(s, a_id):
    from .services import engine_responses
    resp = engine_responses(s, a_id)
    durations = sorted(r["duration"] for r in resp if r.get("duration") and S.completion_state(r) == "COMPLETE")
    med = durations[len(durations) // 2] if durations else 0
    for r in resp:
        r["_state"], r["_flags"] = S.classify_response(r, med)
    return resp

# ------------------------------------------------------------------ findings and reports (Stage 4)


@app.post("/v1/assessments/{a_id}/evaluate")
def evaluate(a_id: str, u=Depends(require(*CONSULTANT)), s=Depends(db)):
    setup, obj, payload, h, ev, leaders = compute_all(s, get_assessment(s, a_id))
    return to_jsonable({"rules_version": cfg.RULES_VERSION, "payload_hash": h, "checks": ev["checks"], "findings": ev["findings"],
                        "scenarios": ev["scenarios"], "blocking": [f["finding_id"] for f in ev["blocking"]]})


@app.get("/v1/assessments/{a_id}/findings")
def findings(a_id: str, u=Depends(require(*CLIENT_READ)), s=Depends(db)):
    if u.role != "PAC_CONSULTANT":
        r = s.scalars(select(Report).where(Report.assessment_id == a_id, Report.status == "RELEASED")).first()
        if not r:
            problem(403, "FORBIDDEN", "Findings are visible after a PAC Consultant releases the report")
    setup, obj, payload, h, ev, leaders = compute_all(s, get_assessment(s, a_id))
    return to_jsonable({"checks": ev["checks"], "c1": ev["c1"], "c2": ev["c2"], "c3": ev["c3"], "c4": ev["c4"],
                        "findings": ev["findings"], "scenarios": ev["scenarios"], "setup": setup})


REPORT_TYPES = ("ORGANISATIONAL", "BOARD_SUMMARY")


def _report(s, a_id, typ):
    r = s.scalars(select(Report).where(Report.assessment_id == a_id, Report.type == typ)).first()
    if not r:
        r = Report(id=nid("rep"), assessment_id=a_id, type=typ, sections={}, accepted={})
        s.add(r); s.commit()
    return r


@app.get("/v1/assessments/{a_id}/reports/{typ}")
def report_get(a_id: str, typ: str, u=Depends(require(*CLIENT_READ)), s=Depends(db)):
    if typ not in REPORT_TYPES:
        problem(404, "NOT_FOUND", "Unknown report type")
    r = _report(s, a_id, typ)
    if u.role != "PAC_CONSULTANT" and r.status != "RELEASED":
        problem(403, "FORBIDDEN", "This report has not been released yet")
    setup, obj, payload, h, ev, leaders = compute_all(s, get_assessment(s, a_id))
    plan = s.scalars(select(Plan).where(Plan.assessment_id == a_id)).first()
    return to_jsonable({"report_id": r.id, "type": typ, "status": r.status, "released_by": r.released_by, "released_at": str(r.released_at) if r.released_at else None,
                        "sections": r.sections, "accepted": r.accepted, "score": payload, "payload_hash": h,
                        "checks": ev["checks"], "c1": ev["c1"], "c2": ev["c2"], "c3": ev["c3"], "c4": ev["c4"], "scenarios": ev["scenarios"],
                        "plan": plan.payload if plan else None})


@app.post("/v1/assessments/{a_id}/reports/{typ}/draft")
def report_draft(a_id: str, typ: str, u=Depends(require(*CONSULTANT)), s=Depends(db)):
    setup, obj, payload, h, ev, leaders = compute_all(s, get_assessment(s, a_id))
    plan = s.scalars(select(Plan).where(Plan.assessment_id == a_id)).first()
    if not plan:
        problem(409, "NOT_PLANNED", "Generate the plan before drafting the narrative")
    secs = ai.draft_sections(obj, ev, plan.payload)
    allowed = ai.allowed_numbers(payload, plan.payload)
    issues = {k: ai.screen(v, allowed) for k, v in secs.items()}
    r = _report(s, a_id, typ)
    r.sections, r.accepted = secs, {}
    s.commit()
    return {"sections": secs, "guardrails": issues}


class SectionEdit(BaseModel):
    section: str
    text: str


@app.post("/v1/assessments/{a_id}/reports/{typ}/accept")
def report_accept(a_id: str, typ: str, body: SectionEdit, u=Depends(require(*CONSULTANT)), s=Depends(db)):
    setup, obj, payload, h, ev, leaders = compute_all(s, get_assessment(s, a_id))
    plan = s.scalars(select(Plan).where(Plan.assessment_id == a_id)).first()
    issues = ai.screen(body.text, ai.allowed_numbers(payload, plan.payload if plan else {}))
    if issues:
        problem(422, "AI_INTEGRITY_BLOCKED", "Text fails a guardrail", issues=issues)
    r = _report(s, a_id, typ)
    r.sections = {**r.sections, body.section: body.text}
    r.accepted = {**r.accepted, body.section: {"by": u.id, "at": str(now())}}
    s.commit()
    return {"ok": True}


@app.post("/v1/assessments/{a_id}/reports/{typ}/release")
def report_release(a_id: str, typ: str, u=Depends(require(*CONSULTANT)), s=Depends(db)):
    r = _report(s, a_id, typ)
    missing = [k for k in ("what_this_means", "what_to_do_next") if not r.sections.get(k) or k not in r.accepted]
    if missing:
        problem(422, "RELEASE_INCOMPLETE", "Mandatory sections must contain accepted text", missing=missing)
    so = latest_score(s, a_id)
    r.status, r.released_by, r.released_at, r.payload_hash = "RELEASED", u.name, now(), so.payload_hash
    e = s.get(Engagement, get_assessment(s, a_id).engagement_id)
    if e.state in ("SCORING", "REPORTING"):
        e.state = "DEBRIEF"
    audit(s, u.id, "RELEASE", r.id)
    s.commit()
    return {"status": "RELEASED", "payload_hash": so.payload_hash}

# ------------------------------------------------------------------ leaders


@app.get("/v1/assessments/{a_id}/leaders")
def leaders(a_id: str, u=Depends(current_user), s=Depends(db)):
    if u.role not in ("PAC_CONSULTANT", "COACH", "PEOPLE_LEADER", "EXECUTIVE") and not (u.role == "CLIENT_ADMIN" and u.is_people_lead):
        problem(403, "FORBIDDEN", "Leader outputs are restricted to the leader, their coach, the people lead and PAC")
    a = get_assessment(s, a_id)
    setup, obj, payload, h, ev, results = compute_all(s, a)
    from .db import LeaderAssignment, Person
    out = []
    for r in results:
        la = s.get(LeaderAssignment, r["assignment_id"])
        person = s.get(Person, la.person_id)
        if u.role == "PEOPLE_LEADER" and u.person_id != la.person_id:
            continue
        item = {"leader_360_id": r["leader_360_id"], "name": person.name, "valid": r["valid"], "counts_toward_tps": a.l360_closed}
        if r["valid"]:
            target = setup["leadership_target_orientation"]
            lp = S.leader_profile(r["other_avg"])
            team = obj["orientation_scores"]["now"]
            item.update({k: r[k] for k in ("self_avg", "other_avg", "default", "growth", "range", "flags", "self_other", "lri", "lri_band", "groups_published")})
            item["fit_index"] = S.fit_index(lp, team); item["fit_band"] = S.fit_band(item["fit_index"])
            item["leader_profile"] = {o: q(v, 2) for o, v in lp.items()}
            item["classification"] = S.carrier_class(lp[target], team[target], r["flags"], r["lri"], r["default"], obj["classification"])
            item["target"] = target
            item["team_basis"] = "computed against the organisation because the team is below the reporting threshold"
        out.append(item)
    audit(s, u.id, "READ_LEADER_OUTPUTS", a_id); s.commit()
    return to_jsonable(out)

# ------------------------------------------------------------------ advisory (Stage 5)


@app.post("/v1/assessments/{a_id}/plan")
def plan_generate(a_id: str, start: str | None = None, u=Depends(require(*CONSULTANT)), s=Depends(db)):
    plan, ev = run_plan(s, get_assessment(s, a_id), u.id, date.fromisoformat(start) if start else None)
    return plan


@app.get("/v1/assessments/{a_id}/plan")
def plan_get(a_id: str, u=Depends(require(*CLIENT_READ)), s=Depends(db)):
    p = s.scalars(select(Plan).where(Plan.assessment_id == a_id)).first()
    if not p:
        problem(404, "NOT_FOUND", "No plan yet")
    return {**p.payload, "p0_complete": p.p0_complete}


class P0Done(BaseModel):
    finding_id: str


@app.post("/v1/assessments/{a_id}/plan/priority-zero/complete")
def p0_complete(a_id: str, body: P0Done, u=Depends(require(*CONSULTANT)), s=Depends(db)):
    p = s.scalars(select(Plan).where(Plan.assessment_id == a_id)).first()
    if body.finding_id not in p.p0_complete:
        p.p0_complete = [*p.p0_complete, body.finding_id]
    audit(s, u.id, "P0_COMPLETE", body.finding_id); s.commit()
    return {"p0_complete": p.p0_complete}


def _action_out(s, a: Action):
    ev = [{"from": e.from_status, "to": e.to_status, "actor": e.actor, "at": str(e.at), "comment": e.comment}
          for e in s.scalars(select(ActionEvent).where(ActionEvent.action_id == a.id).order_by(ActionEvent.at))]
    evid = s.scalar(select(func.count()).select_from(Evidence).where(Evidence.action_id == a.id))
    reads = [float(k.value) for k in s.scalars(select(KpiReading).where(KpiReading.action_id == a.id).order_by(KpiReading.reading_date))]
    d = dict(a.data); d.update(status=a.status, events=ev, evidence_count=evid, kpi_readings=reads)
    if a.status in ("PUBLISHED", "IN_PROGRESS", "UNDER_REVIEW"):
        d["rag"] = P.rag({**a.data, "status": a.status}, date.today(), readings=reads)
    return d


@app.get("/v1/assessments/{a_id}/actions")
def actions(a_id: str, u=Depends(require(*CLIENT_READ)), s=Depends(db)):
    return [_action_out(s, a) for a in s.scalars(select(Action).where(Action.assessment_id == a_id).order_by(Action.id))]


EDITABLE = {"owner", "sponsor", "kpi", "baseline_value", "target_value", "start_date", "end_date", "intervention", "objective", "effort", "budget_amount", "currency"}


@app.patch("/v1/actions/{act_id}")
def action_patch(act_id: str, body: dict, u=Depends(require("PAC_CONSULTANT", "CLIENT_ADMIN", "PEOPLE_LEADER")), s=Depends(db)):
    a = s.get(Action, act_id)
    bad = set(body) - EDITABLE
    if bad:
        problem(422, "VALIDATION_FAILED", "Not editable: " + ", ".join(sorted(bad)))
    d = dict(a.data); d.update(body)
    if "effort" in body:
        d["priority_score"] = format(P.priority_score(d["impact"], d["urgency"], d["effort"]), "f")
    a.data = d
    audit(s, u.id, "ACTION_EDIT", act_id, fields=sorted(body)); s.commit()
    return _action_out(s, a)


class Transition(BaseModel):
    to: str
    reason: str | None = None


@app.post("/v1/actions/{act_id}/transition")
def action_transition(act_id: str, body: Transition, u=Depends(current_user), s=Depends(db)):
    a = s.get(Action, act_id)
    gates = []
    if body.to == "PUBLISHED":
        plan = s.scalars(select(Plan).where(Plan.assessment_id == a.assessment_id)).first()
        pr = next(p for p in plan.payload["priorities"] if p["priority_id"] == a.priority_id)
        gates = [g for g in pr.get("blocked_by", []) if g not in plan.p0_complete]
    evid = s.scalar(select(func.count()).select_from(Evidence).where(Evidence.action_id == act_id))
    new = P.transition({**a.data, "status": a.status}, body.to, u.role, open_gates=gates, evidence_count=evid, reason=body.reason)
    s.add(ActionEvent(id=nid("aev"), action_id=act_id, from_status=a.status, to_status=new["status"], actor=u.name, comment=body.reason))
    a.status = new["status"]
    audit(s, u.id, "ACTION_TRANSITION", act_id, to=body.to); s.commit()
    return _action_out(s, a)


class EvidenceIn(BaseModel):
    type: str
    note: str


@app.post("/v1/actions/{act_id}/evidence")
def evidence(act_id: str, body: EvidenceIn, u=Depends(require("PAC_CONSULTANT", "CLIENT_ADMIN", "PEOPLE_LEADER", "EXECUTIVE")), s=Depends(db)):
    s.add(Evidence(id=nid("evd"), action_id=act_id, type=body.type, note=body.note, uploaded_by=u.name)); s.commit()
    return {"ok": True}


class Reading(BaseModel):
    value: float
    reading_date: str


@app.post("/v1/actions/{act_id}/kpi-readings")
def kpi_reading(act_id: str, body: Reading, u=Depends(require("PAC_CONSULTANT", "CLIENT_ADMIN", "PEOPLE_LEADER")), s=Depends(db)):
    s.add(KpiReading(id=nid("kpi"), action_id=act_id, value=str(body.value), reading_date=body.reading_date)); s.commit()
    return {"ok": True}


@app.get("/v1/dashboards/executive")
def exec_dash(a_id: str, u=Depends(require(*CLIENT_READ)), s=Depends(db)):
    plan = s.scalars(select(Plan).where(Plan.assessment_id == a_id)).first()
    acts = [_action_out(s, a) for a in s.scalars(select(Action).where(Action.assessment_id == a_id))]
    pri = []
    for p in (plan.payload["priorities"] if plan else []):
        mine = [a for a in acts if a["priority_id"] == p["priority_id"]]
        live = [a for a in mine if a.get("rag")]
        worst = "RED" if any(a["rag"] == "RED" for a in live) else "AMBER" if any(a["rag"] == "AMBER" for a in live) else ("GREEN" if live else None)
        pri.append({"priority_id": p["priority_id"], "orientation": p["orientation"], "classification": p["classification"], "owner_role": p["owner_role"],
                    "due": p["due"], "rag": worst, "actions": len(mine), "published": sum(1 for a in mine if a["status"] not in ("DRAFT", "IN_REVIEW", "IN_CO_DESIGN", "APPROVED")),
                    "closed": sum(1 for a in mine if a["status"] == "CLOSED")})
    p0 = plan.payload.get("priority_zero") if plan else None
    return {"priorities": pri, "priority_zero": p0, "p0_complete": plan.p0_complete if plan else []}

# ------------------------------------------------------------------ re-assessment (Stage 6)


class PulseIn(BaseModel):
    priority_id: str
    items: list[str]


@app.post("/v1/assessments/{a_id}/pulses")
def pulse(a_id: str, body: PulseIn, u=Depends(require(*CONSULTANT)), s=Depends(db)):
    plan = s.scalars(select(Plan).where(Plan.assessment_id == a_id)).first()
    pr = next(p for p in plan.payload["priorities"] if p["priority_id"] == body.priority_id)
    watch = pr["actions"][0]["watchlist"]
    errs = R.validate_pulse(body.items, watch)
    if errs:
        problem(422, "PULSE_INVALID", "Pulse is not valid", errors=errs, watchlist=watch)
    return {"status": "SCHEDULED", "items": body.items}


class Simulate(BaseModel):
    now: dict


@app.post("/v1/assessments/{a_id}/trade-off-check")
def tradeoff(a_id: str, body: Simulate, u=Depends(require(*CONSULTANT)), s=Depends(db)):
    so = latest_score(s, a_id)
    plan = s.scalars(select(Plan).where(Plan.assessment_id == a_id)).first()
    base = {o: D(so.payload["orientation_scores"]["now"][o]) for o in ORIENTATIONS}
    cur = {o: D(str(body.now[o])) for o in ORIENTATIONS}
    if sum(cur.values()) != 100:
        problem(422, "VALIDATION_FAILED", "Current profile must sum to 100")
    pr = [{**p, "gap": D(p["gap"])} for p in plan.payload["priorities"]]
    out, unint = R.trade_off_verification(base, cur, pr, so.payload["classification"])
    return to_jsonable({"verification": out, "unintended_release": unint, "delta": {o: cur[o] - base[o] for o in ORIENTATIONS}})


@app.get("/v1/config")
def config_registry(u=Depends(current_user)):
    return to_jsonable({"rules_version": cfg.RULES_VERSION, "instrument_version": cfg.INSTRUMENT_VERSION, "keys": cfg.registry()})


@app.get("/v1/audit")
def audit_log(u=Depends(require("PAC_CONSULTANT", "CLIENT_ADMIN")), s=Depends(db)):
    return [{"at": str(a.at), "actor": a.actor, "action": a.action, "object": a.object_ref} for a in s.scalars(select(AuditLog).order_by(AuditLog.at.desc()).limit(200))]


@app.get("/v1/health")
def health():
    return {"status": "ok", "rules_version": cfg.RULES_VERSION}

# ------------------------------------------------------------------ serve the built front end (single-process mode)
import os as _os
from fastapi.responses import FileResponse as _FileResponse
from fastapi.staticfiles import StaticFiles as _StaticFiles

_DIST = _os.environ.get("CDP_FRONTEND_DIST", _os.path.join(_os.path.dirname(__file__), "..", "..", "frontend", "dist"))
if _os.path.isdir(_DIST):
    app.mount("/assets", _StaticFiles(directory=_os.path.join(_DIST, "assets")), name="assets")

    @app.get("/{path:path}", include_in_schema=False)
    def spa(path: str):
        if path.startswith("v1/"):
            problem(404, "NOT_FOUND", "Unknown endpoint")
        return _FileResponse(_os.path.join(_DIST, "index.html"))
