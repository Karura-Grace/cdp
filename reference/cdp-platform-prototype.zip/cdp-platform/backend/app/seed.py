"""Seed the reference client (spec §0.7). Run: python -m app.seed  (re-creates the local database)."""
import os
import random
from .db import (Base, engine, SessionLocal, Tenant, User, Engagement, OrgUnit, Person, LeaderAssignment, SetupRecord, Assessment,
                 Invitation, Response, Leader360, RaterResponse, nid)
from .fixture import demo_responses, DEPARTMENTS, SETUP, ILLUSTRATIVE_LEADER, ratings_for

T = "ten_demo"


def run(reset=True):
    if reset:
        Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    s = SessionLocal()
    rng = random.Random(7)
    s.add(Tenant(id=T, name="Mwangaza Bank (demo)", legal_name="Mwangaza Bank Limited (fictional)", sector="FINANCIAL_SERVICES", headcount=650,
                 residency_region="af-south", privacy_regime="KE_DPA_2019"))
    s.add(Engagement(id="eng_demo", tenant_id=T, cycle_no=1, state="FIELDING"))
    s.add(OrgUnit(id="dep_00", tenant_id=T, parent_id=None, type="DEPARTMENT", name="Executive Office"))
    for d, name, _ in DEPARTMENTS:
        s.add(OrgUnit(id=d, tenant_id=T, parent_id=None, type="DEPARTMENT", name=name))
    lead_person = Person(id="per_leader", tenant_id=T, unit_id="dep_01", name="Amina Odhiambo", email="amina@mwangaza.example", grade="G4")
    s.add(lead_person)
    s.add(LeaderAssignment(id="lea_leader", person_id="per_leader", team_id="dep_01", headcount_led=12))
    for i in range(63):
        pid = f"per_l{i:02d}"
        s.add(Person(id=pid, tenant_id=T, unit_id=DEPARTMENTS[i % 6][0], name=f"Leader {i+2}", email=f"leader{i+2}@mwangaza.example", grade="G3"))
        s.add(LeaderAssignment(id=f"lea_{i:02d}", person_id=pid, team_id=DEPARTMENTS[i % 6][0], headcount_led=10))
    users = [("usr_admin", None, "admin@pac.africa", "Platform Operations", "SUPER_ADMIN", False, None),
             ("usr_cons", None, "consultant@pac.africa", "Grace Wanjiku (PAC Consultant)", "PAC_CONSULTANT", False, None),
             ("usr_coach", None, "coach@pac.africa", "Peter Kamau (Coach)", "COACH", False, None),
             ("usr_chro", T, "chro@mwangaza.example", "Lucy Mutua (CHRO)", "CLIENT_ADMIN", True, None),
             ("usr_ceo", T, "ceo@mwangaza.example", "David Otieno (CEO)", "EXECUTIVE", False, None),
             ("usr_lead", T, "amina@mwangaza.example", "Amina Odhiambo (Head of Retail)", "PEOPLE_LEADER", False, "per_leader")]
    for uid, t, email, name, role, pl, per in users:
        s.add(User(id=uid, tenant_id=t, email=email, name=name, role=role, is_people_lead=pl, person_id=per))
    wk = ["2026-09-21", ["David Otieno (CEO)", "Lucy Mutua (CHRO)", "Joseph Mwangi (CFO)", "Ruth Achieng (COO)"]]
    sections = {
        "A": {"a1": "Mwangaza Bank (demo)", "a5": "MATURE", "a6": "New three-year digital strategy and rising attrition"},
        "B": {"b1": "Grow digital channels and differentiate on customer experience.", "b2": "THREE_YEARS",
              "b3": [{"text": p["text"], "goal_type": p["goal_type"]} for p in SETUP["priorities"]], "b6_current": "SERVICE_B2C", "b6_planned": None},
        "C": {"kpis": [{"name": "Digital channel adoption (%)", "unit": "PERCENT", "direction": "HIGHER_IS_BETTER", "baseline": 28, "target_12m": 45, "orientation": "INNOVATE"},
                       {"name": "Voluntary attrition (%)", "unit": "PERCENT", "direction": "LOWER_IS_BETTER", "baseline": 19, "target_12m": 13, "orientation": "ENGAGE"},
                       {"name": "Approval cycle time (days)", "unit": "DAYS", "direction": "LOWER_IS_BETTER", "baseline": 21, "target_12m": 7, "orientation": "GOVERN"},
                       {"name": "Customer satisfaction (points)", "unit": "SCORE", "direction": "HIGHER_IS_BETTER", "baseline": 62, "target_12m": 72}],
              "c3": "STABLE", "c5": 19},
        "D": {"d3": "Two million active digital customers with satisfaction above 75 by 2029."},
        "E": {"e1": "Decisions escalate to ExCo; approvals take weeks.", "e6": "Targets without support; good people leave for fintechs."},
        "F": {"f1": [{"text": "Hold a monthly coaching one-to-one with each direct report", "orientation": "ENGAGE"},
                     {"text": "Ask for staff input before decisions that affect them", "orientation": "ENGAGE"},
                     {"text": "Recognise team outcomes publicly every month", "orientation": "ENGAGE"},
                     {"text": "Review progress against a small set of customer KPIs weekly", "orientation": "PERFORM"},
                     {"text": "Run a quarterly career conversation with every team member", "orientation": "ENGAGE"}], "f5": "MODERATE"},
        "G": {"g1": ["Target-only performance reviews"], "g3": ["Monthly coaching conversations"], "g5": ["Regulatory compliance controls"]},
        "H": {"h1": "Annual review against sales targets only", "h5": "Multi-layer sign-offs on small spend"},
        "I": {"cohorts": ["Executive", "Department", "Grade", "Tenure"], "anonymity": "FULL", "languages": ["en-GB"], "window": ["2026-10-05", "2026-10-19"]},
    }
    for sec, payload in sections.items():
        s.add(SetupRecord(id=nid("set"), engagement_id="eng_demo", section=sec, perspective="AGREED", status="AGREED", payload=payload,
                          workshop_date=wk[0], participants=wk[1]))
    s.add(Assessment(id="asm_demo", engagement_id="eng_demo", window_open="2026-10-05", window_close="2026-10-19", status="FIELDING", l360_closed=False))
    for r in demo_responses():
        s.add(Response(id=r["id"], assessment_id="asm_demo", snapshot=r["snapshot"], duration=r["duration"],
                       payload={"alloc": r["alloc"], "likert": r["likert"], "eos": r["eos"]}))
        s.add(Invitation(id=nid("inv"), assessment_id="asm_demo", token=nid("used"), person_id=None, snapshot=r["snapshot"]))
    for i in range(5):   # open tokens for trying the respondent journey
        s.add(Invitation(id=f"inv_try{i+1}", assessment_id="asm_demo", token=f"demo-token-{i+1}", person_id=f"per_l{i:02d}",
                         snapshot={"is_executive": False, "department": "dep_03", "grade": "G2", "tenure_band": "1-3y"}))
    l = Leader360(id="l360_leader", assessment_id="asm_demo", assignment_id="lea_leader", self_ratings=ratings_for(ILLUSTRATIVE_LEADER["self"]))
    s.add(l)
    other = ratings_for(ILLUSTRATIVE_LEADER["other"])
    for g, n in (("SUPERIOR", 1), ("PEER", 3), ("DIRECT_REPORT", 5)):
        for _ in range(n):
            s.add(RaterResponse(id=nid("rr"), leader_360_id=l.id, rater_group=g, ratings=other))
    s.commit()
    s.close()
    print("Seeded: 475 responses, 5 open survey tokens (demo-token-1..5), 1 Leadership 360 (cycle open), 6 demo users.")


if __name__ == "__main__":
    import sys
    if "--if-empty" in sys.argv:
        from sqlalchemy import inspect
        from .db import engine
        if inspect(engine).has_table("tenant"):
            print("Database already seeded; skipping (run without --if-empty to reset).")
            raise SystemExit(0)
    run()
