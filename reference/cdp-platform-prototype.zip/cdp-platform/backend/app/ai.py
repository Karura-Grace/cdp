"""Interpretation drafts and guardrails (spec §4.8).

`draft_sections` produces deterministic template narrative from findings only. An LLM provider can
replace it behind the same contract; every draft — template or model — must pass `screen()` and be
accepted by a named PAC Consultant before release.
"""
import os
import re

DENY_LIST_FILE = os.environ.get("CDP_DENY_LIST", os.path.join(os.path.dirname(__file__), "data", "deny_list.txt"))
CAUSAL = re.compile(r"\b(caused|causes|because of the culture|drove|drives|resulted in|led to)\b", re.I)


def deny_terms():
    try:
        with open(DENY_LIST_FILE, encoding="utf-8") as f:
            return [ln.strip().lower() for ln in f if ln.strip() and not ln.startswith("#")]
    except FileNotFoundError:
        return []


def _numbers(text):
    return set(re.findall(r"-?\d+(?:\.\d+)?", text))


def screen(text, allowed_numbers):
    """Return a list of guardrail violations; empty list = passes."""
    issues = []
    allowed = {str(n) for n in allowed_numbers}
    for n in _numbers(text):
        if n not in allowed and n.lstrip("-") not in allowed:
            issues.append(f"NUMERIC_INTEGRITY: {n} is not in the findings payload")
    low = text.lower()
    for t in deny_terms():
        if t in low:
            issues.append("TERMINOLOGY: deny-listed term")
    if CAUSAL.search(text):
        issues.append("CAUSAL_LANGUAGE: use associational wording")
    return issues


def draft_sections(score, ev, plan):
    rd, now = score["readiness"], score["orientation_scores"]["now"]
    dom = score["dominance"]["dominant"][0]
    c = ev["checks"]
    judgement = (f"The culture as measured does not yet support the declared strategy. The dominant orientation is {dom} "
                 f"({now[dom]}), while the digital growth strategy requires INNOVATE above 28; INNOVATE is the weakest orientation ({now['INNOVATE']}). "
                 f"Check C1 is a {c['C1'].replace('_', ' ')} and C4 is a {c['C4'].replace('_', ' ')}.") if c["C1"] != "HIT" else \
        f"The culture as measured supports the declared strategy; the dominant orientation is {dom} ({now[dom]})."
    shadows = [o for o, f in (score.get("perception_flags") or {}).items() if f == "SHADOW_CULTURE"]
    means = [judgement]
    if shadows:
        means.append("Executives and staff describe different organisations on " + " and ".join(shadows) +
                     "; leaders must see the staff picture before any intervention is announced.")
    means.append(f"Readiness sets the pace: the Transformation Probability Score is {rd['tps']} ({rd['tps_band'].replace('_', ' ').lower()}), "
                 f"so no more than {plan['cap']} priorities can run in this cycle.")
    nxt = []
    if plan.get("priority_zero"):
        nxt.append("Within 30 days, complete the pre-conditions owned by the CEO and CHRO: " +
                   "; ".join(i["item"] for i in plan["priority_zero"]["items"]) + ".")
    for p in plan["priorities"]:
        t = f" releasing {p['trade_off_orientation']}" if p.get("trade_off_orientation") else ""
        nxt.append(f"Priority {p['sequence']}: {p['classification'].lower().replace('_', ' ')} {p['orientation']}{t}, owned by {p['owner_role'].replace('+', ' and ')}, due {p['due']}.")
    return {"what_this_means": " ".join(means), "what_to_do_next": " ".join(nxt)}


def allowed_numbers(score, plan):
    nums = set()

    def walk(x):
        if isinstance(x, dict):
            for v in x.values():
                walk(v)
        elif isinstance(x, (list, tuple)):
            for v in x:
                walk(v)
        elif isinstance(x, str):
            nums.update(_numbers(x))
        elif isinstance(x, (int, float)):
            nums.add(str(x))
        else:
            try:
                nums.add(format(x, "f"))
            except (TypeError, ValueError):
                pass
    walk(score); walk(plan)
    nums.update({"28", "30", "1", "2", "3", "4", "0", "5", "6", "7", "8", "9"})
    return nums
