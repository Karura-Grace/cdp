"""Relational store (spec Appendix A, condensed). SQLite for local use; PostgreSQL via DATABASE_URL."""
import os
import uuid
from datetime import datetime, timezone
from sqlalchemy import create_engine, String, Integer, Boolean, DateTime, JSON, ForeignKey, Text, event
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker

DATABASE_URL = os.environ.get("DATABASE_URL", "sqlite:///./cdp.db")
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {})
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)


def now():
    return datetime.now(timezone.utc)


def nid(prefix):
    return f"{prefix}_{uuid.uuid4().hex[:10]}"


class Base(DeclarativeBase):
    pass


class Tenant(Base):
    __tablename__ = "tenant"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    name: Mapped[str] = mapped_column(String)
    legal_name: Mapped[str] = mapped_column(String)
    sector: Mapped[str] = mapped_column(String)
    headcount: Mapped[int] = mapped_column(Integer)
    residency_region: Mapped[str] = mapped_column(String)
    privacy_regime: Mapped[str] = mapped_column(String)
    timezone: Mapped[str] = mapped_column(String, default="Africa/Nairobi")
    config: Mapped[dict] = mapped_column(JSON, default=dict)


class User(Base):
    __tablename__ = "app_user"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    tenant_id: Mapped[str | None] = mapped_column(String, nullable=True)
    email: Mapped[str] = mapped_column(String, unique=True)
    name: Mapped[str] = mapped_column(String)
    role: Mapped[str] = mapped_column(String)          # SUPER_ADMIN, PAC_CONSULTANT, CLIENT_ADMIN, EXECUTIVE, PEOPLE_LEADER, COACH
    is_people_lead: Mapped[bool] = mapped_column(Boolean, default=False)
    person_id: Mapped[str | None] = mapped_column(String, nullable=True)


class Engagement(Base):
    __tablename__ = "engagement"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenant.id"))
    cycle_no: Mapped[int] = mapped_column(Integer, default=1)
    state: Mapped[str] = mapped_column(String, default="SETUP")


class OrgUnit(Base):
    __tablename__ = "org_unit"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    tenant_id: Mapped[str] = mapped_column(String)
    parent_id: Mapped[str | None] = mapped_column(String, nullable=True)
    type: Mapped[str] = mapped_column(String)
    name: Mapped[str] = mapped_column(String)


class Person(Base):
    __tablename__ = "person_of_record"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    tenant_id: Mapped[str] = mapped_column(String)
    unit_id: Mapped[str] = mapped_column(String)
    name: Mapped[str] = mapped_column(String)
    email: Mapped[str] = mapped_column(String)
    grade: Mapped[str] = mapped_column(String)
    is_executive: Mapped[bool] = mapped_column(Boolean, default=False)


class LeaderAssignment(Base):
    __tablename__ = "leader_assignment"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    person_id: Mapped[str] = mapped_column(String)
    team_id: Mapped[str] = mapped_column(String)
    headcount_led: Mapped[int] = mapped_column(Integer)


class SetupRecord(Base):
    __tablename__ = "setup_record"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    engagement_id: Mapped[str] = mapped_column(String)
    section: Mapped[str] = mapped_column(String)
    perspective: Mapped[str] = mapped_column(String, default="AGREED")
    status: Mapped[str] = mapped_column(String, default="DRAFT")
    payload: Mapped[dict] = mapped_column(JSON, default=dict)
    workshop_date: Mapped[str | None] = mapped_column(String, nullable=True)
    participants: Mapped[list] = mapped_column(JSON, default=list)


class Assessment(Base):
    __tablename__ = "assessment"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    engagement_id: Mapped[str] = mapped_column(String)
    instrument_version: Mapped[str] = mapped_column(String, default="1.1")
    rules_version: Mapped[str] = mapped_column(String, default="2.0")
    window_open: Mapped[str] = mapped_column(String)
    window_close: Mapped[str] = mapped_column(String)
    status: Mapped[str] = mapped_column(String, default="DRAFT")    # DRAFT, FIELDING, FROZEN, SCORED
    frozen_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    response_set_hash: Mapped[str | None] = mapped_column(String, nullable=True)
    l360_closed: Mapped[bool] = mapped_column(Boolean, default=False)


class Invitation(Base):
    __tablename__ = "invitation"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    assessment_id: Mapped[str] = mapped_column(String)
    token: Mapped[str] = mapped_column(String, unique=True)   # demo stores token; production stores only a hash
    person_id: Mapped[str | None] = mapped_column(String, nullable=True)
    snapshot: Mapped[dict] = mapped_column(JSON)
    submitted_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    link_destroyed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    draft: Mapped[dict | None] = mapped_column(JSON, nullable=True)


class Consent(Base):
    __tablename__ = "consent_record"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    invitation_id: Mapped[str | None] = mapped_column(String, nullable=True)
    text_version: Mapped[str] = mapped_column(String)
    decision: Mapped[str] = mapped_column(String)
    at: Mapped[datetime] = mapped_column(DateTime, default=now)


class Response(Base):
    __tablename__ = "response"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    assessment_id: Mapped[str] = mapped_column(String)
    snapshot: Mapped[dict] = mapped_column(JSON)
    language: Mapped[str] = mapped_column(String, default="en-GB")
    duration: Mapped[int | None] = mapped_column(Integer, nullable=True)
    payload: Mapped[dict] = mapped_column(JSON)          # alloc, likert, eos
    text: Mapped[dict] = mapped_column(JSON, default=dict)   # encrypted at rest in production
    voided_reason: Mapped[str | None] = mapped_column(String, nullable=True)
    submitted_at: Mapped[datetime] = mapped_column(DateTime, default=now)


class Leader360(Base):
    __tablename__ = "leader_360"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    assessment_id: Mapped[str] = mapped_column(String)
    assignment_id: Mapped[str] = mapped_column(String)
    self_ratings: Mapped[list | None] = mapped_column(JSON, nullable=True)


class RaterResponse(Base):
    __tablename__ = "rater_response"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    leader_360_id: Mapped[str] = mapped_column(String)
    rater_group: Mapped[str] = mapped_column(String)
    ratings: Mapped[list] = mapped_column(JSON)


class ScoreObject(Base):
    __tablename__ = "score_object"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    assessment_id: Mapped[str] = mapped_column(String)
    version: Mapped[int] = mapped_column(Integer)
    payload: Mapped[dict] = mapped_column(JSON)
    payload_hash: Mapped[str] = mapped_column(String)
    frozen: Mapped[bool] = mapped_column(Boolean, default=False)


class Evaluation(Base):
    __tablename__ = "evaluation"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    assessment_id: Mapped[str] = mapped_column(String)
    payload: Mapped[dict] = mapped_column(JSON)


class Plan(Base):
    __tablename__ = "plan"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    assessment_id: Mapped[str] = mapped_column(String)
    payload: Mapped[dict] = mapped_column(JSON)
    p0_complete: Mapped[list] = mapped_column(JSON, default=list)


class Action(Base):
    __tablename__ = "action"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    assessment_id: Mapped[str] = mapped_column(String)
    priority_id: Mapped[str] = mapped_column(String)
    status: Mapped[str] = mapped_column(String)
    data: Mapped[dict] = mapped_column(JSON)


class ActionEvent(Base):
    __tablename__ = "action_event"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    action_id: Mapped[str] = mapped_column(String)
    from_status: Mapped[str] = mapped_column(String)
    to_status: Mapped[str] = mapped_column(String)
    actor: Mapped[str] = mapped_column(String)
    comment: Mapped[str | None] = mapped_column(Text, nullable=True)
    at: Mapped[datetime] = mapped_column(DateTime, default=now)


class Evidence(Base):
    __tablename__ = "evidence"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    action_id: Mapped[str] = mapped_column(String)
    type: Mapped[str] = mapped_column(String)
    note: Mapped[str] = mapped_column(Text)
    uploaded_by: Mapped[str] = mapped_column(String)
    at: Mapped[datetime] = mapped_column(DateTime, default=now)


class KpiReading(Base):
    __tablename__ = "kpi_reading"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    action_id: Mapped[str] = mapped_column(String)
    value: Mapped[float] = mapped_column(String)
    reading_date: Mapped[str] = mapped_column(String)


class Report(Base):
    __tablename__ = "report"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    assessment_id: Mapped[str] = mapped_column(String)
    type: Mapped[str] = mapped_column(String)
    status: Mapped[str] = mapped_column(String, default="DRAFT")
    sections: Mapped[dict] = mapped_column(JSON, default=dict)
    accepted: Mapped[dict] = mapped_column(JSON, default=dict)
    released_by: Mapped[str | None] = mapped_column(String, nullable=True)
    released_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    payload_hash: Mapped[str | None] = mapped_column(String, nullable=True)


class AuditLog(Base):
    __tablename__ = "audit_log"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    tenant_id: Mapped[str | None] = mapped_column(String, nullable=True)
    actor: Mapped[str] = mapped_column(String)
    action: Mapped[str] = mapped_column(String)
    object_ref: Mapped[str] = mapped_column(String)
    detail: Mapped[dict] = mapped_column(JSON, default=dict)
    at: Mapped[datetime] = mapped_column(DateTime, default=now)


class SegmentQueryLog(Base):
    __tablename__ = "segment_query_log"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    actor: Mapped[str] = mapped_column(String)
    predicates: Mapped[dict] = mapped_column(JSON)
    resolved_count: Mapped[int] = mapped_column(Integer)
    outcome: Mapped[str] = mapped_column(String)
    at: Mapped[datetime] = mapped_column(DateTime, default=now)


def init_db():
    Base.metadata.create_all(engine)
