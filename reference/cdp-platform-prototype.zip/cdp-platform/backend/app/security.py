"""Authentication and role checks (spec §0.5).

Demo mode issues signed bearer tokens on e-mail login. Production replaces `login` with OIDC + MFA;
everything downstream (roles, scope, permissions) is unchanged.
"""
import hashlib
import hmac
import os
from fastapi import Depends, Header, HTTPException
from .db import SessionLocal, User

SECRET = os.environ.get("CDP_SECRET", "dev-secret-change-me").encode()


def sign(uid: str) -> str:
    return uid + "." + hmac.new(SECRET, uid.encode(), hashlib.sha256).hexdigest()[:32]


def verify(token: str):
    uid, _, sig = token.partition(".")
    if not uid or not hmac.compare_digest(sign(uid), token):
        return None
    return uid


def db():
    s = SessionLocal()
    try:
        yield s
    finally:
        s.close()


def current_user(authorization: str = Header(default=""), s=Depends(db)) -> User:
    tok = authorization.removeprefix("Bearer ").strip()
    uid = verify(tok) if tok else None
    u = s.get(User, uid) if uid else None
    if not u:
        raise HTTPException(401, {"code": "UNAUTHENTICATED", "title": "Sign in required"})
    return u


def require(*roles):
    def dep(u: User = Depends(current_user)):
        if u.role not in roles:
            raise HTTPException(403, {"code": "FORBIDDEN", "title": f"{u.role} cannot perform this operation"})
        return u
    return dep


CONSULTANT = ("PAC_CONSULTANT",)
CLIENT_READ = ("PAC_CONSULTANT", "CLIENT_ADMIN", "EXECUTIVE", "PEOPLE_LEADER")
