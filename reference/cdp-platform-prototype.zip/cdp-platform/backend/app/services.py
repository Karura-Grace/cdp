"""Glue between the store and the pure engines."""
import json
from datetime import date
from sqlalchemy import select
from .db import (Assessment, Engagement, SetupRecord, Response, Leader360, RaterResponse, LeaderAssignment, Person,
                 ScoreObject, Evaluation, Plan, Action, AuditLog, nid)
from .engine import scoring as S, checks as C, planning as P
from .engine.num import to_jsonable, D, q


def audit(s, actor, action, obj, tenant_id=None, **detail):
    s.add(AuditLog(id=nid("aud"), tenant_id=tenant_id, actor=actor, action=action, object_ref=obj, detail=to_jsonable(detail)))


def setup_records(s, eng_id):
    return {r.section: r for r in s.scalars(select(SetupRecord).where(SetupRecord.engagement_id == eng_id, SetupRecord.perspective == "AGREED"))}


def engine_setup(s, eng_id):
    rec = setup_records(s, eng_id)
    b, f = rec["B"].payload, rec["F"].payload
    kpis = rec["C"].payload.get("kpis", [])
    return {
        "leadership_target_orientation": C.leadership_target([x["orientation"] for x in f["f1"]], f.get("tie_break")),
        "c1_requirements": C.c1_requirements([{"ref": f"B3.{i+1}", "goal_type": p["goal_type"]} for i, p in enumerate(b["b3"])]),
        "c4_requirement": C.c4_requirement(b["b6_current"], b.get("b6_planned")),
        "kpi_for": {k["orientation"]: {"name": k["name"], "baseline": k["baseline"], "target": k["target_12m"]} for k in kpis if k.get("orientation")},
    }


def engine_responses(s, a_id):
    out = []
    for r in s.scalars(select(Response).where(Response.assessment_id == a_id).order_by(Response.id)):
        out.append({"id": r.id, "duration": r.duration, "snapshot": r.snapshot, "voided": bool(r.voided_reason), **r.payload})
    return out


def leader_inputs(s, a: Assessment, target):
    scope = [{"assignment_id": la.id, "headcount_led": la.headcount_led} for la in s.scalars(select(LeaderAssignment))]
    results = []
    for l in s.scalars(select(Leader360).where(Leader360.assessment_id == a.id)):
        raters = [{"group": rr.rater_group, "ratings": rr.ratings} for rr in s.scalars(select(RaterResponse).where(RaterResponse.leader_360_id == l.id))]
        res = S.score_leader(l.self_ratings, raters, target)
        la = s.get(LeaderAssignment, l.assignment_id)
        res.update(leader_360_id=l.id, assignment_id=l.assignment_id, headcount_led=la.headcount_led if la else 0)
        results.append(res)
    counted = [r for r in results if r.get("valid") and a.l360_closed]
    return results, counted, scope


def run_score(s, a: Assessment, actor):
    setup = engine_setup(s, a.engagement_id)
    resp = engine_responses(s, a.id)
    results, counted, scope = leader_inputs(s, a, setup["leadership_target_orientation"])
    obj, payload, h = S.score_assessment(resp, setup, counted, scope)
    prev = s.scalars(select(ScoreObject).where(ScoreObject.assessment_id == a.id).order_by(ScoreObject.version.desc())).first()
    if prev and prev.payload_hash == h:
        return obj, prev
    so = ScoreObject(id=nid("sco"), assessment_id=a.id, version=(prev.version + 1 if prev else 1), payload=payload, payload_hash=h)
    s.add(so)
    a.status = "SCORED"
    audit(s, actor, "SCORE", a.id, hash=h)
    s.commit()
    return obj, so


def compute_all(s, a: Assessment):
    """Deterministic recomputation of score → evaluation → plan (engine objects, not persisted)."""
    setup = engine_setup(s, a.engagement_id)
    resp = engine_responses(s, a.id)
    results, counted, scope = leader_inputs(s, a, setup["leadership_target_orientation"])
    obj, payload, h = S.score_assessment(resp, setup, counted, scope)
    ev = C.evaluate(obj, setup)
    return setup, obj, payload, h, ev, results


def run_plan(s, a: Assessment, actor, start=None):
    setup, obj, payload, h, ev, _ = compute_all(s, a)
    plan = P.build_plan(obj, ev, setup, start or date.today())
    for p in plan["priorities"]:
        p["blocked_by"] = P.blocked_by(p, ev)
    jp = to_jsonable(plan)
    existing = s.scalars(select(Plan).where(Plan.assessment_id == a.id)).first()
    if existing:
        existing.payload = jp
    else:
        s.add(Plan(id=nid("pln"), assessment_id=a.id, payload=jp))
    if not s.scalars(select(Action).where(Action.assessment_id == a.id)).first():
        for p in jp["priorities"]:
            for act in p["actions"]:
                s.add(Action(id=act["action_id"], assessment_id=a.id, priority_id=p["priority_id"], status="DRAFT", data=act))
    s.add(Evaluation(id=nid("evl"), assessment_id=a.id, payload=to_jsonable(ev)))
    audit(s, actor, "PLAN", a.id)
    s.commit()
    return jp, ev
