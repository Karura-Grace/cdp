"""End-to-end API test through all six stages on the seeded reference client."""
import os
os.environ["DATABASE_URL"] = "sqlite:///./test_api.db"
import pytest
from fastapi.testclient import TestClient


@pytest.fixture(scope="module")
def client():
    from app import seed
    seed.run()
    from app.main import app
    with TestClient(app) as c:
        yield c


def tok(c, email):
    return {"Authorization": "Bearer " + c.post("/v1/auth/login", json={"email": email}).json()["token"]}


def test_end_to_end(client):
    c = client
    cons, ceo, chro = tok(c, "consultant@pac.africa"), tok(c, "ceo@mwangaza.example"), tok(c, "chro@mwangaza.example")
    assert c.post("/v1/assessments/asm_demo/preflight", headers=cons).json()["pass"]
    # Stage 2: respondent journey and validation
    sv = c.get("/v1/survey", params={"token": "demo-token-1"}).json()
    assert len(sv["instrument"]["scenarios"]) == 18
    bad = {"consent": True, "alloc": {"NOW": {"D1": [{"ENGAGE": 30, "INNOVATE": 30, "PERFORM": 30, "GOVERN": 20}]}}, "submit": False}
    r = c.put("/v1/survey/response", params={"token": "demo-token-1"}, json=bad)
    assert r.status_code == 422 and r.json()["code"] == "CONSTANT_SUM_VIOLATION"
    # Stage 3
    assert c.post("/v1/assessments/asm_demo/score", headers=cons).status_code == 409   # not frozen
    c.post("/v1/assessments/asm_demo/freeze", headers=cons)
    sc = c.post("/v1/assessments/asm_demo/score", headers=cons).json()
    assert sc["score"]["readiness"]["tps"] == "3.09" and sc["score"]["orientation_scores"]["now"]["INNOVATE"] == "14.00"
    h1 = sc["payload_hash"]
    assert c.post("/v1/assessments/asm_demo/score", headers=cons).json()["payload_hash"] == h1   # deterministic
    # Stage 4
    ev = c.post("/v1/assessments/asm_demo/evaluate", headers=cons).json()
    assert ev["checks"] == {"C1": "MISS", "C2": "MISS", "C3": "SYSTEMIC_MISS", "C4": "PARTIAL_HIT"}
    assert [x["scenario_id"] for x in ev["scenarios"]] == ["SC-05", "SC-01", "SC-10"]
    assert c.get("/v1/assessments/asm_demo/findings", headers=ceo).status_code == 403   # not released
    # Stage 5
    plan = c.post("/v1/assessments/asm_demo/plan", headers=cons, params={"start": "2026-11-02"}).json()
    assert [p["orientation"] for p in plan["priorities"]] == ["INNOVATE", "ENGAGE", "GOVERN"]
    c.post("/v1/assessments/asm_demo/reports/ORGANISATIONAL/draft", headers=cons)
    assert c.post("/v1/assessments/asm_demo/reports/ORGANISATIONAL/release", headers=cons).status_code == 422
    rep = c.get("/v1/assessments/asm_demo/reports/ORGANISATIONAL", headers=cons).json()
    for k in ("what_this_means", "what_to_do_next"):
        r = c.post("/v1/assessments/asm_demo/reports/ORGANISATIONAL/accept", headers=cons, json={"section": k, "text": rep["sections"][k]})
        assert r.status_code == 200, r.json()
    bad = c.post("/v1/assessments/asm_demo/reports/ORGANISATIONAL/accept", headers=cons, json={"section": "what_this_means", "text": "Attrition fell 47 points."})
    assert bad.json()["code"] == "AI_INTEGRITY_BLOCKED"
    assert c.post("/v1/assessments/asm_demo/reports/ORGANISATIONAL/release", headers=cons).json()["status"] == "RELEASED"
    assert c.get("/v1/assessments/asm_demo/findings", headers=ceo).status_code == 200
    acts = c.get("/v1/assessments/asm_demo/actions", headers=cons).json()
    eng = next(a for a in acts if a["orientation"] == "ENGAGE" and not a["is_visible_signal"])
    aid = eng["action_id"]
    assert c.post(f"/v1/actions/{aid}/transition", headers=ceo, json={"to": "APPROVED"}).json()["code"] == "ILLEGAL_TRANSITION"
    c.post(f"/v1/actions/{aid}/transition", headers=cons, json={"to": "IN_REVIEW"})
    c.post(f"/v1/actions/{aid}/transition", headers=cons, json={"to": "IN_CO_DESIGN"})
    assert c.post(f"/v1/actions/{aid}/transition", headers=ceo, json={"to": "APPROVED"}).json()["code"] == "VALIDATION_FAILED"
    c.patch(f"/v1/actions/{aid}", headers=chro, json={"owner": "Lucy Mutua", "sponsor": "David Otieno", "budget_amount": 2500000, "currency": "KES"})
    assert c.post(f"/v1/actions/{aid}/transition", headers=ceo, json={"to": "APPROVED"}).json()["status"] == "APPROVED"
    r = c.post(f"/v1/actions/{aid}/transition", headers=cons, json={"to": "PUBLISHED"})
    assert r.json()["code"] == "BLOCKING_GATE_OPEN"
    for f in plan["priority_zero"]["items"]:
        c.post("/v1/assessments/asm_demo/plan/priority-zero/complete", headers=cons, json={"finding_id": f["finding_id"]})
    assert c.post(f"/v1/actions/{aid}/transition", headers=cons, json={"to": "PUBLISHED"}).json()["status"] == "PUBLISHED"
    # Leaders and Stage 6
    ld = c.get("/v1/assessments/asm_demo/leaders", headers=cons).json()[0]
    assert ld["lri"].startswith("2.92") and ld["classification"] == "NEUTRAL"
    assert c.get("/v1/assessments/asm_demo/leaders", headers=ceo).status_code == 200
    tv = c.post("/v1/assessments/asm_demo/trade-off-check", headers=cons, json={"now": {"ENGAGE": 26, "INNOVATE": 19, "PERFORM": 31, "GOVERN": 24}}).json()
    assert tv["verification"][0]["verdict"] == "INTENDED_RELEASE"
    pu = c.post("/v1/assessments/asm_demo/pulses", headers=cons, json={"priority_id": "pri_01", "items": ["D7", "Q99"]})
    assert pu.status_code == 422
