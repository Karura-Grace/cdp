"""Unit tests mirroring specification Appendix D (UT-xx)."""
from decimal import Decimal as D
import pytest
from app.engine import scoring as S, checks as C, planning as P, reassess as R, suppression as X, config as cfg
from app.engine.num import q, ORIENTATIONS
from app.fixture import demo_responses, SETUP, DIM_NOW, ratings_for, ILLUSTRATIVE_LEADER

NOW = dict(zip(ORIENTATIONS, map(D, [22, 14, 34, 30])))
PREF = dict(zip(ORIENTATIONS, map(D, [31, 25, 28, 16])))
DIMS = {d: dict(zip(ORIENTATIONS, map(D, v))) for d, v in DIM_NOW.items()}


@pytest.fixture(scope="module")
def full():
    setup = {"leadership_target_orientation": C.leadership_target(SETUP["f1_tags"]),
             "c1_requirements": C.c1_requirements(SETUP["priorities"]), "c4_requirement": C.c4_requirement("SERVICE_B2C"),
             "kpi_for": SETUP["kpi_for"]}
    obj, payload, h = S.score_assessment(demo_responses(), setup, [], [{"headcount_led": 10}] * 64)
    ev = C.evaluate(obj, setup)
    plan = P.build_plan(obj, ev, setup)
    return setup, obj, payload, h, ev, plan


def test_ut03_gaps_sum_zero():
    g = S.gaps(NOW, PREF)
    assert [g[o] for o in ORIENTATIONS] == [D("9.00"), D("11.00"), D("-6.00"), D("-14.00")] and sum(g.values()) == 0


@pytest.mark.parametrize("g,cls,sig", [("8.00", "BUILD", True), ("7.99", "STRENGTHEN", False), ("4.00", "STRENGTHEN", False),
                                       ("3.99", "KEEP_AND_PROTECT", False), ("-3.99", "KEEP_AND_PROTECT", False),
                                       ("-4.00", "MODERATE", False), ("-8.00", "MODERATE", True)])
def test_ut04_gap_boundaries(g, cls, sig):
    assert S.classify_gap(D(g)) == cls and S.significant(D(g)) == sig


def test_ut05_strength():
    assert S.culture_strength(NOW) == (D("9.00"), "MODERATE")


def test_ut06_congruence():
    lenses = S.lens_profiles(DIMS)
    c = S.congruence(NOW, DIMS, lenses)
    assert c["dimension_count"] == 4 and c["dimension_pct"] == D("66.7") and c["band"] == "MODERATELY_CONGRUENT"
    assert c["lens"]["agreement"] == 2 and c["lens"]["PRACTICE"] == "GOVERN"


def test_ut07_shared_dominance():
    d = S.dominance({"ENGAGE": D(20), "INNOVATE": D("19.6"), "PERFORM": D("30.4"), "GOVERN": D(30)})
    assert d["shared"] and d["dominant"] == ["PERFORM", "GOVERN"]


def test_ut08_eos_category():
    assert S.eos_category([9] * 30 + [7] * 25 + [3] * 45) == -15


def test_ut09_eos_index():
    assert q(sum(map(D, [18, 9, -8, 6, 11, -14, 21, 14])) / 8, 1) == D("7.1")


def test_ut10_tps_rounding():
    t = S.tps(D("3.2"), D("2.8"), D("3.1"), D("3.40"))
    assert t == D("3.085") and q(t, 2) == D("3.09") and round(3.085, 2) == 3.08  # float would be wrong
    assert S.band_1_5(t) == "ENABLEMENT_REQUIRED" and S.priority_cap(t) == 3


@pytest.mark.parametrize("v,b", [("2.49", "HIGH_RISK"), ("2.50", "ENABLEMENT_REQUIRED"), ("3.49", "ENABLEMENT_REQUIRED"),
                                 ("3.50", "TARGETED_SUPPORT"), ("3.99", "TARGETED_SUPPORT"), ("4.00", "STRONG_READINESS")])
def test_ut11_tps_bands(v, b):
    assert S.band_1_5(D(v)) == b


def test_ut12_weights():
    assert sum(cfg.GLOBAL["scoring.tps.weights"]) == D("1.00")


def test_ut13_blend():
    la_i = S.la_instrument(D(18), "ENGAGE")
    assert la_i == D("3.4")
    assert q(S.leadership_alignment(D("0.42"), D("3.25"), la_i), 2) == D("3.34")


def test_ut14_c1():
    r = C.alignment_verdict(C.c1_requirements([{"ref": "B3.1", "goal_type": "INNOVATION_NEW_MODELS"}])[0], NOW)
    assert r["verdict"] == "MISS" and r["alignment_pct"] == D("50.0") and "OVERRIDE_2_LOWEST" in r["overrides"]


def test_ut15_c4():
    r = C.alignment_verdict(C.c4_requirement("SERVICE_B2C"), NOW)
    assert r["verdict"] == "PARTIAL_HIT" and r["alignment_pct"] == D("86.7") and r["overrides"] == ["OVERRIDE_1_BELOW_THRESHOLD"]


def test_ut16_capping():
    now = {"ENGAGE": D(20), "INNOVATE": D(15), "PERFORM": D(45), "GOVERN": D(20)}
    r = C.alignment_verdict(C.c1_requirements([{"ref": "x", "goal_type": "RESULTS_GROWTH"}])[0], now)
    assert r["alignment_pct"] == D("100.0") and r["verdict"] == "HIT"


def test_ut17_transition():
    r = C.alignment_verdict(C.c4_requirement("SERVICE_B2C", planned="PLATFORM_DIGITAL"), NOW)
    assert r["alignment_pct"] == D("87.5") and r["verdict"] == "PARTIAL_HIT" and "OVERRIDE_2_LOWEST" not in r["overrides"]


def test_ut18_c2():
    r = C.behaviour_gap(DIMS, "ENGAGE")
    assert (r["verdict"], r["rank"], r["behaviour_gap_points"], r["intensity"]) == ("MISS", 3, D("14.00"), "SUBSTANTIVE")


def test_ut19_c3_systemic():
    cls = {o: S.classify_gap(g) for o, g in S.gaps(NOW, PREF).items()}
    r = C.stop_start(DIMS, cls)
    assert r["verdict"] == "SYSTEMIC_MISS" and r["identity_risk"] and r["offending"] == ["PERFORM"]


@pytest.mark.parametrize("g,f", [("5.0", "NONE"), ("5.1", "WATCH"), ("7.0", "WATCH"), ("7.1", "SHADOW_CULTURE")])
def test_ut20_perception(g, f):
    assert S.perception_flag(D(g)) == f


def test_ut22_cap_two(full):
    setup, obj, *_ , ev, _ = full
    obj2 = dict(obj); obj2["readiness"] = dict(obj["readiness"], tps=D("2.40"))
    plan = P.build_plan(obj2, ev, setup)
    assert [p["orientation"] for p in plan["priorities"]] == ["INNOVATE", "ENGAGE"]
    assert plan["backlog"][0]["orientation"] == "GOVERN" and plan["backlog"][0]["reason"] == "readiness cap"


def test_ut24_stepping_stone(full):
    plan = full[5]
    eng = next(p for p in plan["priorities"] if p["orientation"] == "ENGAGE")
    assert eng["pathway"]["relationship"] == "DIAGONAL" and eng["pathway"]["stepping_stone"] == "GOVERN"


def test_ut25_adjacent(full):
    inn = next(p for p in full[5]["priorities"] if p["orientation"] == "INNOVATE")
    assert inn["pathway"]["relationship"] == "ADJACENT_OUTWARD" and inn["pathway"]["stepping_stone"] is None


def test_ut26_gate_blocks_publish():
    a = {"status": "APPROVED", "horizon": "MEDIUM_3_12M"}
    with pytest.raises(P.WorkflowError) as e:
        P.transition(a, "PUBLISHED", "PAC_CONSULTANT", open_gates=["fnd_0005"])
    assert e.value.code == "BLOCKING_GATE_OPEN"


def test_ut27_floor():
    with pytest.raises(X.Suppressed):
        X.check_floor(4)


def test_ut29_differencing():
    assert X.differencing_suppressed(22, {"team_a": 18, "team_b": 4}) == {"team_a", "team_b"}


def test_ut30_rater_group_merge():
    rat = ratings_for(ILLUSTRATIVE_LEADER["other"])
    raters = [{"group": "PEER", "ratings": rat}] * 2 + [{"group": "DIRECT_REPORT", "ratings": rat}] * 3 + [{"group": "SUPERIOR", "ratings": rat}]
    r = S.score_leader(ratings_for(ILLUSTRATIVE_LEADER["self"]), raters, "ENGAGE")
    assert "PEER" not in r["groups_published"] and "ALL_OTHERS" in r["groups_published"]


def test_ut31_lri():
    other = {"A": D("2.9"), "B": D(3), "C": D(3), "D": D(3), "E": D(4), "F": D("3.2"), "G": D("3.4"), "H": D("3.6")}
    r = S.compute_leader_readings(other, other, "ENGAGE")
    assert q(r["lri"], 2) == D("3.31") and r["lri_band"] == "ENABLEMENT_REQUIRED"


@pytest.mark.parametrize("g,t", [("0.50", "ALIGNED"), ("0.51", "WATCH"), ("1.00", "WATCH"), ("1.01", "BLIND_SPOT")])
def test_ut32_tiers(g, t):
    base = {s: D(3) for s in "ABCDEFGH"}
    self_ = dict(base, A=D(3) + D(g))
    assert S.compute_leader_readings(self_, base, "ENGAGE")["self_other"]["A"]["tier"] == t


def test_ut33_integrity_flag():
    o = {s: D(4) for s in "ABCDEFGH"}; o["E"] = D("3.95")
    assert "INTEGRITY" in S.compute_leader_readings(o, o, "ENGAGE")["flags"]


def test_ut34_fit():
    lp = dict(zip(ORIENTATIONS, map(D, [40, 20, 25, 15])))
    f = S.fit_index(lp, NOW)
    assert f == D("76.00") and S.fit_band(f) == "ALIGNED"


def test_ut35_blocker():
    cls = {"ENGAGE": "BUILD", "INNOVATE": "BUILD", "PERFORM": "MODERATE", "GOVERN": "MODERATE"}
    assert S.carrier_class(D(15), D(22), [], D("3.0"), ["PERFORM"], cls) == "CULTURE_BLOCKER"


def test_ut36_determinism(full):
    setup = full[0]
    hashes = {S.score_assessment(demo_responses(), setup, [], [{"headcount_led": 10}])[2] for _ in range(3)}
    assert len(hashes) == 1


def test_ut42_pulse():
    errs = R.validate_pulse([f"D8 i{i}" for i in range(12)], ["D8 i0"])
    assert len(errs) == 2


def test_ut43_versions():
    assert R.comparability("1.0", "1.1") == "SAME" and R.comparability("1.1", "2.0") == "MAJOR"


def test_ut45_zero_coverage(full):
    rd = full[1]["readiness"]
    assert rd["coverage"] == 0 and rd["leadership_alignment"] == D("3.4000") and rd["tps"] == D("3.09") and rd["provisional"]


def test_ut46_full_coverage():
    assert S.leadership_alignment(D(1), D("3.60"), D("2.10")) == D("3.6000")


def test_ut47_continuity():
    a = S.leadership_alignment(D("0.599"), D("3.6"), D("2.1")); b = S.leadership_alignment(D("0.601"), D("3.6"), D("2.1"))
    assert abs(a - b) < D("0.01")


@pytest.mark.parametrize("g,i", [("4.9", "MARGINAL"), ("5.0", "SUBSTANTIVE"), ("14.9", "SUBSTANTIVE"), ("15.0", "ENTRENCHED")])
def test_ut48_intensity(g, i):
    dims = {"D2": {"ENGAGE": D(10), "INNOVATE": D(10) + D(g), "PERFORM": D(40), "GOVERN": D(40) - D(g)},
            "D3": {"ENGAGE": D(10), "INNOVATE": D(10) + D(g), "PERFORM": D(40), "GOVERN": D(40) - D(g)}}
    r = C.behaviour_gap(dims, "GOVERN")
    assert r["intensity"] == i


def test_ut49_shared():
    dims = {d: {"ENGAGE": D("30.8"), "INNOVATE": D(20), "PERFORM": D("31.6"), "GOVERN": D("17.6")} for d in ("D2", "D3")}
    assert C.behaviour_gap(dims, "ENGAGE")["verdict"] == "HIT"
    dims = {d: {"ENGAGE": D("30.6"), "INNOVATE": D(20), "PERFORM": D("31.6"), "GOVERN": D("17.8")} for d in ("D2", "D3")}
    assert C.behaviour_gap(dims, "ENGAGE")["verdict"] == "PARTIAL_HIT"


def test_ut51_c3_partial():
    dims = dict(DIMS); dims["D4"] = {"ENGAGE": D(40), "INNOVATE": D(10), "PERFORM": D(30), "GOVERN": D(20)}
    cls = {"ENGAGE": "BUILD", "INNOVATE": "BUILD", "PERFORM": "MODERATE", "GOVERN": "MODERATE"}
    r = C.stop_start(dims, cls)
    assert r["verdict"] == "PARTIAL_HIT" and not r["identity_risk"]


def test_ut52_override3():
    now = {"ENGAGE": D(20), "INNOVATE": D(30), "PERFORM": D(34), "GOVERN": D(16)}
    r = C.alignment_verdict(C.c4_requirement("PLATFORM_DIGITAL"), now)
    assert r["alignment_pct"] == D("100.0") and r["verdict"] == "PARTIAL_HIT"


def test_ut53_lagging():
    cls = {"ENGAGE": "BUILD", "INNOVATE": "BUILD", "PERFORM": "MODERATE", "GOVERN": "MODERATE"}
    assert S.carrier_class(D(15), D(22), [], D("3.2"), ["INNOVATE"], cls) == "LAGGING"


def test_ut54_readiness_banding():
    assert S.readiness_band_index(D("3.04")) == 1 and S.readiness_band_index(D("3.05")) == 2 and S.readiness_band_index(D("2.96")) == 1


def test_ut55_observed_minimum():
    rat = [None] * 5 + [3] * 5 + [3] * 50
    assert S.section_avg(rat, "A") is None and S.section_avg(rat, "B") == 3


def test_ut56_quality_exclusion():
    r = demo_responses()[0]
    r = dict(r, duration=100)
    r["alloc"] = {"NOW": {d: [{o: 25 for o in ORIENTATIONS}] * 3 for d in DIM_NOW}, "PREFERRED": r["alloc"]["PREFERRED"]}
    st, fl = S.classify_response(r, 2500)
    assert st == "INSUFFICIENT" and "SPEEDING" in fl and "UNIFORM_ALLOCATION" in fl


def test_ut57_multiple_c1(full):
    setup, obj, *_ = full
    s2 = dict(setup, c1_requirements=C.c1_requirements([{"ref": "B3.1", "goal_type": "RESULTS_GROWTH"}, {"ref": "B3.2", "goal_type": "INNOVATION_NEW_MODELS"}]))
    ev = C.evaluate(obj, s2)
    assert len(ev["c1"]) == 2 and ev["checks"]["C1"] == "MISS"


def test_ut58_59_plan(full):
    plan = full[5]
    assert [(p["orientation"], p["urgency_tier"], p["trade_off_orientation"]) for p in plan["priorities"]] == [
        ("INNOVATE", "STRATEGIC_MISS", "GOVERN"), ("ENGAGE", "BEHAVIOUR_GAP", "PERFORM"), ("GOVERN", "PROCESS_CONTRADICTION", None)]
    assert next(p for p in plan["priorities"] if p["orientation"] == "ENGAGE")["c3_levers"]
    assert len(plan["priority_zero"]["items"]) == 5


def test_ut60_illustrative_leader():
    other = {k: D(str(v)) for k, v in ILLUSTRATIVE_LEADER["other"].items()}
    selfa = {k: D(str(v)) for k, v in ILLUSTRATIVE_LEADER["self"].items()}
    r = S.compute_leader_readings(selfa, other, "ENGAGE")
    assert q(r["lri"], 2) == D("2.92") and "SAFETY" in r["flags"] and r["self_other"]["F"]["tier"] == "BLIND_SPOT"
    lp = S.leader_profile(other)
    assert S.fit_index(lp, NOW) == D("91.44")
    cls = {"ENGAGE": "BUILD", "INNOVATE": "BUILD", "PERFORM": "MODERATE", "GOVERN": "MODERATE"}
    assert S.carrier_class(lp["ENGAGE"], D(22), r["flags"], r["lri"], r["default"], cls) == "NEUTRAL"


def test_ut61_tradeoff():
    base = NOW
    cur = {"ENGAGE": D(26), "INNOVATE": D(19), "PERFORM": D(31), "GOVERN": D(24)}
    pr = [{"priority_id": "pri_01", "orientation": "INNOVATE", "classification": "BUILD", "trade_off_orientation": "GOVERN"},
          {"priority_id": "pri_02", "orientation": "ENGAGE", "classification": "BUILD", "trade_off_orientation": "PERFORM"}]
    out, unint = R.trade_off_verification(base, cur, pr, {})
    assert out[0]["verdict"] == "INTENDED_RELEASE" and out[0]["share_trade_off"] == D("0.67")
    assert out[1]["verdict"] == "MIXED_RELEASE" and out[1]["share_trade_off"] == D("0.33")


def test_ut62_action_score():
    assert P.priority_score(5, 5, 3) == D("8.33")


def test_workflow_rules():
    a = {"status": "DRAFT", "horizon": "MEDIUM_3_12M"}
    with pytest.raises(P.WorkflowError):
        P.transition(a, "APPROVED", "EXECUTIVE")            # cannot skip co-design
    a = P.transition(a, "IN_REVIEW", "PAC_CONSULTANT")
    a = P.transition(a, "IN_CO_DESIGN", "PAC_CONSULTANT")
    with pytest.raises(P.WorkflowError) as e:
        P.transition(a, "APPROVED", "EXECUTIVE")
    assert e.value.code == "VALIDATION_FAILED"
    a.update(owner="p1", sponsor="p2", kpi="k", baseline_value=1, target_value=2, start_date="2026-11-01", end_date="2027-06-01")
    a = P.transition(a, "APPROVED", "EXECUTIVE")
    assert a["status"] == "APPROVED"


def test_scenarios(full):
    assert [s["scenario_id"] for s in full[4]["scenarios"]] == ["SC-05", "SC-01", "SC-10"]
