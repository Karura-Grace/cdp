# CDP Platform – Culture Dynamics Profile

A working full-stack implementation of the **CDP Platform Developer Specification v2.1 (Final)** for Priority Activator Consulting (PAC). It covers the engagement lifecycle from end to end:

**Setup → Assessment → Scoring → Reporting → Advisory → Re-assessment**

It comes loaded with a demonstration client, *Mwangaza Bank (demo)*: 475 responses, a leader 360 and an agreed setup. Every worked example in the specification is reproduced exactly and checked by automated tests.

---

## 1. Quick start

### Option A: one click (Windows)
1. Install **Python 3.11+** (tick "Add to PATH") and **Node.js 20+**.
2. Unzip `cdp-platform.zip` and double-click **`start-windows.bat`**.
3. Your browser opens at **http://localhost:8000**. Choose a demo user to sign in.

The first run takes a few minutes while it installs packages and builds the interface. Later runs start in seconds. To restore the demo data at any time, run `reset-demo-windows.bat`.

### Option B: macOS / Linux
```bash
./start.sh            # then open http://localhost:8000
```

### Option C: Docker (PostgreSQL, production-like)
```bash
docker compose up --build
# UI  → http://localhost:8080      API → http://localhost:8000/docs
```

### Option D: developer mode (hot reload)
```bash
cd backend && python -m venv .venv && . .venv/bin/activate    # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python -m app.seed                      # creates cdp.db with the demo client
uvicorn app.main:app --reload --port 8000

cd ../frontend && npm install && npm run dev   # http://localhost:5173 (proxies /v1 to :8000)
```

Interactive API documentation (OpenAPI) is at **http://localhost:8000/docs**.

---

## 2. Demo users

| User | Role | What they see |
|---|---|---|
| consultant@pac.africa | PAC Consultant | Everything; runs freeze, scoring, plan, narrative and release |
| admin@pac.africa | PAC Admin | Tenant administration and configuration |
| coach@pac.africa | Coach | Leader 360 outputs |
| chro@mwangaza.example | Client Admin (people lead) | Setup, monitoring, plan; released reports |
| ceo@mwangaza.example | Executive | Released reports, dashboard, action approval |
| amina@mwangaza.example | People Leader | Their own 360; their actions |

Employee survey links (single use): `http://localhost:8000/survey/demo-token-1` to `demo-token-5`.

Sign-in is a demo picker. Production replaces it with OIDC/SAML SSO and MFA for PAC roles (spec §8). The token-signing secret is set by `CDP_SECRET`.

---

## 3. Suggested walkthrough (about 10 minutes)

Sign in as **consultant@pac.africa** and follow the left-hand navigation:

1. **Setup**: review Sections A–I, the derived C1, C4 and leadership-target requirements, then **Run launch checks** (L2–L6).
2. **Assessment**: open a survey link in a new tab and try the constant-sum control (it enforces exactly 100). Then **Freeze response set**.
3. **Scoring**: **Run scoring**. You should see TPS **3.09**, INNOVATE NOW **14.00**, SHADOW CULTURE on ENGAGE and GOVERN, and eOS index 7.1.
4. **Segments**: department heat-map with suppression below 5 respondents and sub-culture tests.
5. **Findings**: C1 MISS (50.0%), C2 MISS (rank 3, gap 14.0, substantive), C3 SYSTEMIC MISS, C4 PARTIAL HIT (86.7%); scenarios SC-05, SC-01, SC-10.
6. **Action plan**: **Generate plan**. Priority zero, then BUILD INNOVATE (trade-off GOVERN), BUILD ENGAGE (diagonal via GOVERN, C3 levers) and MODERATE GOVERN. Move actions through the workflow. Publishing stays blocked until the gating priority-zero items are marked complete.
7. **Reports**: **Draft narrative**, edit if needed, **Accept** both mandatory sections (the guardrails check every number), then **Release**.
8. **Leader 360**: illustrative leader with LRI 2.92, fit 91.44 (MIRRORED), NEUTRAL, safety flag.
9. **Executive dashboard** and **Re-assessment**: run the trade-off verification simulator and schedule a pulse from a priority's watchlist.

Then sign in as **ceo@mwangaza.example** to see the client view after release.

---

## 4. Architecture

```
frontend/  React 18 + TypeScript + Vite + Recharts (PAC navy #1C2B4A / orange #E8610A)
  src/pages/        one page per stage (Setup, Fielding, Survey, Scoring, Segments, Findings,
                    Reports, Leaders, Plan, Dashboard, Reassess, Admin)
  src/components/   UI primitives and charts (profile, gap, TPS gauge, perception, eOS, 360)
backend/   FastAPI + SQLAlchemy 2 (SQLite locally, PostgreSQL via DATABASE_URL)
  app/engine/       PURE, deterministic rules engines – no I/O, Decimal arithmetic (ROUND_HALF_UP)
    num.py          numeric core, rounding helpers
    config.py       configuration registry (rules version 2.0, instrument 1.1)
    scoring.py      response states & quality flags, orientation profiles, gaps & classes,
                    dominance, strength, congruence/lenses, D7–D9 & alpha, eOS, TPS & leadership
                    alignment, perception gap, sub-cultures (SDI + Welch t-test), leader 360
    checks.py       requirements (C1/C4), C1–C4 verdicts with overrides, scenarios SC-01…SC-12
    planning.py     priority zero, cap by TPS, candidates, urgency tiers, pathways & stepping
                    stones, action generation, priority score, workflow state machine, RAG
    reassess.py     trade-off verification, pulse validation/triggers, adjust-or-retire
    suppression.py  anonymity floors (5 / 3 / 8) and differencing protection
  app/services.py   orchestration: DB → engine inputs → score object (sha256 payload hash)
  app/ai.py         narrative drafting + guardrails (numeric integrity, terminology, causal wording)
  app/main.py       REST API /v1 (problem+json errors, role checks, audit log)
  app/seed.py       demo client generator (exact fixture reproduction)
  tests/            72 tests: unit tests per spec UT-xx + an end-to-end API journey
```

**Design principles carried over from the specification**
- Scoring is deterministic and reproducible. The same frozen response set always gives the same payload hash.
- Every threshold comes from the versioned configuration registry (`GET /v1/config`). Changing a key creates a new rules version and never alters frozen results.
- Privacy: identity is unlinked from answers at submission, groups below the reporting threshold are suppressed, segment queries are logged, and leader outputs are restricted by role.
- Findings drive the plan: every priority links to findings, gating findings become priority-zero items, and actions cannot be published past an open gate.
- AI is optional and constrained. It produces template drafts only, every number must exist in the score object, and a consultant accepts each section before release.

---

## 5. Running the tests

```bash
cd backend && python -m pytest -q        # 72 passed
```

Key regressions include: TPS 3.085 → **3.09** (a float gives 3.08), the C1/C4 overrides, C2 rank and intensity, the C3 count, the scenario order, plan composition, workflow gates, suppression, and a deterministic hash.

---

## 6. Configuration

| Variable | Default | Purpose |
|---|---|---|
| `DATABASE_URL` | `sqlite:///./cdp.db` | e.g. `postgresql+psycopg://user:pass@host:5432/cdp` |
| `CDP_SECRET` | `dev-secret-change-me` | token-signing secret. **Change in production** |
| `CDP_DENY_LIST` | `app/data/deny_list.txt` | restricted-terminology list used by the narrative guardrail |
| `CDP_FRONTEND_DIST` | `../frontend/dist` | built UI served by the API in single-process mode |

---

## 7. Moving to production

This codebase is a complete reference implementation. Before go-live, add the following platform services, each described in the specification:
- SSO (OIDC/SAML) and MFA in place of the demo sign-in.
- Email and SMS invitation delivery and reminders.
- PDF rendering for reports.
- Object storage for evidence files.
- Encryption at rest and per-tenant keys.
- Data-residency deployment, backups and monitoring.
- An LLM provider behind `app/ai.py`, which keeps the same guardrails.

© Priority Activator Consulting. Proprietary and confidential.
